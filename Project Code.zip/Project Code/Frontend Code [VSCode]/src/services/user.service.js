import axios from 'axios';
import authHeader from './auth-header';

const API_URL = 'http://localhost:4040/api/test/';

class UserService {
  getPublicContent() {
    return axios.get(API_URL + 'all');
  }

  getUserPage() {
    return axios.get(API_URL + 'user', { headers: authHeader() });
  }

  getAdminPage() {
    return axios.get(API_URL + 'admin', { headers: authHeader() });
  }

  getFacultyPage() {
    return axios.get(API_URL + 'faculty', { headers: authHeader() });
  }

  getStudentPage() {
    return axios.get(API_URL + 'student', { headers: authHeader() });
  }

 
}

export default new UserService();
