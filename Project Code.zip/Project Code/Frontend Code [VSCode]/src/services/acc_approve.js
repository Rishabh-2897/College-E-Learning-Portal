import axios from "axios";

const ACCOUNT_BASE_URL="http://localhost:6060/acc_approve";
class accountService{
    getAccounts(){
        return axios.get(ACCOUNT_BASE_URL);
    }
}

export default new accountService;