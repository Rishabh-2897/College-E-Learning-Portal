import React, { Component } from "react";
import { Link } from "react-router-dom";
import { ListGroup } from "reactstrap";

class home_menu2 extends Component {
    render() {
        return (
            <ListGroup className="mt-1">
                <Link className="pt-4 pb-4  text-center list-group-item list-group-item-action" to="/" action>Carrier Options</Link>
                <Link className="pt-4 pb-4  text-center list-group-item list-group-item-action" to="/" action>About Institution</Link>
                <Link className="pt-4 pb-4  text-center list-group-item list-group-item-action" to="/" action>Contact Us</Link>
                <Link className="pt-4 pb-4  text-center list-group-item list-group-item-action" to="/" action>About Us</Link>
                <Link className="pt-4 pb-4  text-center list-group-item list-group-item-action" to="/" action>Developer Details</Link>

            </ListGroup>


        );
    }
}

export default home_menu2;
