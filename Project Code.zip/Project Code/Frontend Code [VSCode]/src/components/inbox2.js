import React, { Fragment,Component } from "react";
import { Form, Col, Row, Table } from 'reactstrap';
import { Link } from "react-router-dom";
import messageService from "../services/message";

class inbox2 extends Component {
    constructor(props) {
        super(props);

        this.state = {
            messages: []
        }

    }

      //TO GET ALL MESSAGES:-  
      componentWillMount() {
        document.title = "Inbox Messages";
       messageService.getMessages().then((res) =>{
        this.setState({messages: res.data.result});
       // console.log(JSON.stringify(res.data.result));
        //  console.log(res.data.result[0]);
       
          alert("Loading Messages"); 
    })
      }
 
    render() {
        return (
            <Fragment>
                <Row className="mt-3">
                    <Col md={1}>
                    </Col>
                    <Col md={9}>
                        <Form>
                            <Col>
                                <h3 className="bg-info text-center p-2" style={{ color: "white" }}>Inbox Messages</h3>

                                <Table className="text-center" responsive striped hover bordered size="sm">
                                    <thead>
                                        <tr>
                                          
                                            <th className="pb-3">Message Body</th>
                                           

                                        </tr>
                                    </thead>
                                    <tbody>
                                    {
                                        this.state.messages.map(
                                            mesage =>
                                                <tr key={mesage.id}>
                                                    <td>{mesage.text}</td>
                                                   
                                                </tr>

                                        )
                                    }

                                    </tbody>
                                </Table>
                            </Col>

                        </Form>
                    </Col>
                </Row>


            </Fragment>
        );
    }
}

export default inbox2;