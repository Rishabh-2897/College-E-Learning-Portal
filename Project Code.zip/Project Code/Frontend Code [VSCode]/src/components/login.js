import React, { Fragment, Component } from "react";
import { FormGroup, Label, Container, Row, Col } from "reactstrap";
import { Link } from "react-router-dom";
import Form from "react-validation/build/form";
import Input from "react-validation/build/input";
import CheckButton from "react-validation/build/button";
import AuthService from "../services/auth.service";
import { toast, Flip } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const required = value => {
    if (!value) {
        return (
            <div className="alert alert-danger" role="alert">
                This field is required!
            </div>
        );
    }
};

class login extends Component {

    constructor(props) {
        super(props);

        this.state = {

            userName: "",
            password: "",
            loading: false,
            message: ""

        }
        //BINDING ALL EVENTS:-
        this.handleLogin = this.handleLogin.bind(this);
        this.onChangeUsername = this.onChangeUsername.bind(this);
        this.onChangePassword = this.onChangePassword.bind(this);

    }

    onChangeUsername(e) {
        this.setState({
            userName: e.target.value
        });
    }

    onChangePassword(e) {
        this.setState({
            password: e.target.value
        });
    }

    handleLogin(e) {
        e.preventDefault();

        this.setState({
            message: "",
            loading: true
        });

        this.form.validateAll();

        if (this.checkBtn.context._errors.length === 0) {
            // CALLING LOGIN SERVICE
            AuthService.login(this.state.userName, this.state.password).then(() => {
                //DIRECTING TO AUTHORS PAGE:
                
                //GETTING VALIDATED USER DETAILS FROM LOCALSTORAGE:
                const res=localStorage.getItem("user");

                if(res.role === 'ROLE_ADMIN')
                {
                    this.props.history.push("/admin");
                }
                else if(res.role === 'ROLE_FACULTY')
                {
                    this.props.history.push("/faculty");
                }
                else if(res.role === 'ROLE_STUDENT')
                {
                    this.props.history.push("/student");
                }
                toast.success('Login Successfull...', {
                    position: "top-center",
                    autoClose: 3000,
                    transition: Flip,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: false,
                    draggable: true,
                    progress: undefined,
                  });
                this.props.history.push("./");
                window.location.reload();
                // alert('Login Successfull...');

               
            },
                error => {
                    // IF ANY ERROR OCCURS:
                    const resMessage =
                        (error.response && error.response.data &&
                            error.response.data.message) || error.message || error.toString();

                    // SET THE MESSAGE:
                    this.setState({
                        loading: false,
                        message: resMessage

                    });
                    // alert('Sorry... Wrong Credentials !!!');
                    toast.error('Wrong Credentials...', {
                            position: "top-center",
                            autoClose: 3000,
                            transition: Flip,
                            hideProgressBar: true,
                            closeOnClick: true,
                            pauseOnHover: false,
                            draggable: true,
                            progress: undefined,
                          });
                }
            );
        } else {
            this.setState({
                loading: false
                
            });
            
        }
    }


    render() {
        return (
            <Fragment>
                <Form
                    onSubmit={this.handleLogin}
                    ref={
                        c => { this.form = c; }
                    }
                    className="mt-5"
                >

                    <Row form>
                        <Col md={4}>
                        </Col>
                        <Col style={{ border: "4px solid #c2ffd1", boxShadow: "1px 6px 10px 0px grey" }} className="mt-3 p-4" md={4}>
                        
                        <h3 className="bg-primary p-2 text-center" style={{ color: "white" }}>Login Panel</h3>
                        <FormGroup>
                            <Label for="Email">Email</Label>
                            <Input type="email"  name="userName" 
                            className="form-control"
                            placeholder="Enter Username"
                            value={this.state.userName}
                            onChange={this.onChangeUsername}
                            validations={[required]}  
                            />
                        </FormGroup>

                        <FormGroup>
                            <Label for="Password">Password</Label>
                            <Input type="password" placeholder="Enter Password"
                             name="password"
                             className="form-control"
                             value={this.state.password}
                             onChange={this.onChangePassword}
                             validations={[required]}
                             />
                        </FormGroup>

                        <Container className="text-center" >
                        <CheckButton
                        style={{ display: "none" }}
                        ref={
                            c => {this.checkBtn = c;}
                            }
                        />
                        <button
                        className="btn btn-outline-success btn-block"
                        disabled={this.state.loading}
                        >
                        <span>Login </span>
                        {
                            this.state.loading && (<span className="spinner-border spinner-border-sm"></span>)
                        }

                        </button>
                        {/* <Input type="reset" className="btn btn-outline-danger ml-2">Reset</Input> */}
                        <br />
                        <Link to="/registration" action>Don't have a account ?</Link>
                        </Container>

                        </Col>
                        <Col md={4}>
                        </Col>
                    </Row>
                </Form>
            </Fragment>
        );
    }
}

export default login;
