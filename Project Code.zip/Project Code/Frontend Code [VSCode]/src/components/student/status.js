import React, { Fragment, useEffect, useState, Component } from "react";
import { Link } from "react-router-dom";
import { Progress, Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from "reactstrap";

class status extends Component {

    constructor(props) {
        super(props);

        this.state = {
        
        }

    }
    
    render() {
        return (
            <Fragment>
            <Row className="m-1">
                <Col md={1}></Col>
                <Col md={8}>
                <h3 style={{color:"white"}} className="p-2 text-center bg-info">Subject Completion Status</h3>
                </Col>
            </Row>
            <Row>
                <Col>
                    <Row>
                        <Col md={1}>
                        </Col>
                        <Col md={8}>
                            <Label>JAVA</Label>
                            <Progress animated barStyle style={{ height: 18, fontSize: 18 }} color="success" value="25" >25 %</Progress>
                            <hr />
                        </Col>

                    </Row>

                    <Row>
                        <Col md={1}>
                        </Col>
                        <Col md={8}>
                            <Label>AWS</Label>
                            <Progress animated barStyle style={{ height: 18, fontSize: 18 }} color="success" value="75" >75 %</Progress>
                            <hr />
                        </Col>

                    </Row>
                </Col>
            </Row>

        </Fragment>
        );
    }
}

export default status;
  