import React, { Fragment, useEffect, useState ,Component } from "react";
import { Link } from "react-router-dom";
import { Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from "reactstrap";


class select_subject extends Component {

    constructor(props) {
        super(props);

        this.state = {
        
        }

    }

    render() {
        return (
            <Fragment>
            <Row className="m-1">
                <Col md={1}></Col>
                <Col md={8}>
                    <h3 style={{ color: "white" }} className="p-2 text-center bg-info">My Subjects</h3>
                </Col>
            </Row>

            <Row>

                <Col md={1}></Col>
                <Col md={2} style={{ border: "2px solid #dedddc", textDecoration: "none" }} className="ml-2 text-center">

                    <Link to="../SE" action>

                        <Row>
                            <Col>
                                <Label className="p-2" style={{fontSize:"20px", color: "grey" }}>SE</Label>
                            </Col>
                        </Row>

                    </Link>
                </Col>

                <Col md={2} style={{ border: "2px solid #dedddc", textDecoration: "none" }} className="ml-2 text-center">
                    <Link to="../ADJAVA" action>
                        
                        <Row>
                            <Col>
                                <Label className="p-2" style={{fontSize:"20px", color: "grey" }}>ADJAVA</Label>
                            </Col>
                        </Row>
                    </Link>
                </Col>

                <Col md={2} style={{ border: "2px solid #dedddc", textDecoration: "none" }} className="ml-2 text-center">
                    <Link to="../JAVA" action>
                        
                        <Row>
                            <Col>
                                <Label className="p-2" style={{fontSize:"20px",color: "grey" }}>JAVA</Label>
                            </Col>
                        </Row>
                    </Link>
                </Col>

                <Col md={2} style={{ border: "2px solid #dedddc", textDecoration: "none" }} className="ml-2 text-center">
                    <Link to="../AWP" action>
                        
                        <Row>
                            <Col>
                                <Label className="p-2" style={{fontSize:"20px", color: "grey" }}>AWP</Label>
                            </Col>
                        </Row>
                    </Link>
                </Col>

            </Row>

        </Fragment>
        );
    }
}

export default select_subject;
