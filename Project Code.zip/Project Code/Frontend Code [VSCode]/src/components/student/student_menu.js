import React, { Fragment, useEffect, useState, Component } from "react";
import { Link } from "react-router-dom";
import { ListGroup } from "reactstrap";

class student_menu extends Component {

    constructor(props) {
        super(props);

        this.state = {
        
        }

    }
    
    render() {
        return (
            <ListGroup>
            <Link className="text-center list-group-item list-group-item-action" to="/student/study_material" action>Study Material</Link>
            <Link className="text-center list-group-item list-group-item-action" to="/student/recordings" action>Recordings Session</Link>
            <Link className="text-center list-group-item list-group-item-action" to="/student/syllabus_status" action>Syllabus Status</Link>
            <Link className="text-center list-group-item list-group-item-action" to="/student/exams" action>Exams</Link>

            </ListGroup>
        );
    }
}

export default student_menu;
        
