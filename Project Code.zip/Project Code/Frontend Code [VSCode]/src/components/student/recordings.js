import React, { Fragment, useEffect, useState, Component } from "react";
import { Link } from "react-router-dom";
import { Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from "reactstrap";
import VideoLibraryIcon from '@material-ui/icons/VideoLibrary';

class recordings extends Component {

    constructor(props) {
        super(props);

        this.state = {
        
        }

    }

    render() {
        return (
            <Fragment>
            <Row className="m-1">
                <Col md={1}></Col>
                <Col md={8}>
                <h3 style={{color:"white"}} className="p-2 text-center bg-info">Learning Point</h3>
                </Col>
            </Row>
            <Row>
                <Col md={3}>
                </Col>
                <Col md={2} style={{border:"2px solid #dedddc", textDecoration:"none"}} className="p-3 text-center">
                    <Link to="/student/session_rec" action>

                    <Row>
                        <Col>
                            <VideoLibraryIcon color="action" style={{ opacity:"0.3",fontSize: 110 }} />
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Label style={{color:"grey"}}>Session Recordings</Label>
                        </Col>
                    </Row>

                    </Link>
                </Col>

                <Col md={2} style={{border:"2px solid #dedddc", textDecoration:"none"}} className="p-3 text-center">
                <Link to="/student/guest_lec" action>
                    <Row>
                        <Col>
                            <VideoLibraryIcon color="action" style={{ opacity:"0.3", fontSize: 110 }} />
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Label style={{color:"grey"}}>Guest Sessions</Label>
                        </Col>
                    </Row>
                    </Link>
                </Col>

               

            </Row>

        </Fragment>
        );
    }
}

export default recordings;
        