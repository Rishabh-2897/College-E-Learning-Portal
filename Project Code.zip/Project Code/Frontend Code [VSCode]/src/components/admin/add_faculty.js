import React, { Fragment, Component } from "react";
import { Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from "reactstrap";
import facultyService from "../../services/faculty";
import departmentService from "../../services/department";
import { toast, Flip } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

class add_faculty extends Component {

    constructor(props) {
        super(props);

        this.state = {
            //TO GET ID FROM URL (params)
            id: this.props.match.params.id,

            //TO GET ALL DEPT DEATAILS TO DISPLAY
            departments: [],
            // departments: [{dept_id:'1',dept_name:'computer'},
            // {dept_id:'2',dept_name:'BE'},
            // {dept_id:'3',dept_name:'ME'}],

            //TO GET ALL FACULTIES TO DISPLAY IN TABLE
            faculties: [],
            // faculties: [{
            //     faculty_id: '1', d_id: 'computer',
            //     faculty_name: "abc", contact_no: '456987',
            //     username: 'abcdfg'
            // }],

            //TO GET FACULTIES DETAILS ONE BY ONE ON FORM
            faculty_name: '',
            d_id: '',
            contact_no: '',
            email: '',
            username: '',
            specialization: '',
            password: '',

        }
        //BINDING ALL THE EVENTS
        //FOR FILEDS
        this.changeDeptNameHandler = this.changeDeptNameHandler.bind(this);
        this.changeFacultyNameHandler = this.changeFacultyNameHandler.bind(this);
        this.changeContactHandler = this.changeContactHandler.bind(this);
        this.changeEmailHandler = this.changeEmailHandler.bind(this);
        this.changeUsernameHandle = this.changeUsernameHandle.bind(this);
        this.changePasswordHandler = this.changePasswordHandler.bind(this);
        this.changeSpecHandler = this.changeSpecHandler.bind(this);
        //FOR BUTTONS
        this.saveOrUpdateFaculty = this.saveOrUpdateFaculty.bind(this);
        this.editFaculty = this.editFaculty.bind(this);
        this.deleteFaculty = this.deleteFaculty.bind(this);

    }
 
    componentDidMount() {
         //TO GET ALL DEPARTMENTS:-
        departmentService.getDeparments().then((res) => {
            console.log("RESPONSE:- ",JSON.stringify(res.data.result));
            this.setState({ departments: res.data.result });
        })
        //TO GET ALL FACULTIES:-
        facultyService.getFaculties().then((res) => {
            this.setState({ faculties: res.data.result });
        })

        alert("(1)Loading Faculty Details...");
    }

    //EVENT HANDLER TO FILL THE DATA IN FIELD
    changeDeptNameHandler = (event) => {
        this.setState({ d_id: event.target.value });

    }

    changeFacultyNameHandler = (event) => {
        this.setState({ faculty_name: event.target.value });

    }
    changeContactHandler = (event) => {
        this.setState({ contact_no: event.target.value });

    }
    changeEmailHandler = (event) => {
        this.setState({ email: event.target.value });

    }
    changeUsernameHandle = (event) => {
        this.setState({ username: event.target.value });

    }
    changeSpecHandler = (event) => {
        this.setState({ specialization: event.target.value });

    }
    changePasswordHandler = (event) => {
        this.setState({ password: event.target.value });

    }

    //TO SAVE THE FORM DATA
    saveOrUpdateFaculty = (e) => {
        e.preventDefault();
        let fac = {
            d_id: this.state.d_id,
            faculty_name: this.state.faculty_name,
            contact_no: this.state.contact_no,
            email: this.state.email,
            specialization: this.state.specialization,
            username: this.state.username,
            password: this.state.password,
        };

        //TO PRINT DATA ON CONSOLE
        console.log('fac =>' + JSON.stringify(fac));

        if (this.state.id > 0) {
            //TO UPDATE THE DATA FROM COURSE_ID
            facultyService.updateFacultyByID(fac, this.state.id).then((res) => {
                this.props.history.push('/admin/add_faculty');
                alert("Updated Succcesfully...");

            });

        } else {
            //TO SAVE/CREATE DATA TO SERVER
            facultyService.createFaculty(fac).then((res) => {
                this.props.history.push('/admin/add_faculty');
                //alert("Registred Succcesfully...");
                toast.success('Registred Succcesfully...', {
                    position: "top-center",
                    autoClose: 3000,
                    transition: Flip,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: false,
                    draggable: true,
                    progress: undefined,
                  });
            });

        }

    }

    //EVENT TO GET FACULTY DETAIL BY ID
    editFaculty(id) {
        this.props.history.push(`/admin/add_faculty/${id}`);
       
    }

    //EVENT TO DELETE FACULTY DETAIL BY ID
    deleteFaculty(id) {
        facultyService.deleteFacultyByID(id).then((res) => {
            //JUST FILTERING DEPT ARRAY DATA
            this.setState({ faculties: this.state.faculties.filter(fac => fac.id !== id) });
            //alert("Record Deleted...");
            toast.error('Record Deleted...', {
                position: "top-center",
                autoClose: 3000,
                transition: Flip,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: false,
                draggable: true,
                progress: undefined,
              });
        })

    }

    //TO UPDATE FORM DATA FROM FACULTY ID
    componentDidMount() {
        if (this.state.id > 0) {
            facultyService.getFacultyByID(this.state.id).then((res) => {
                let fac = res.data.result;
                this.setState({ d_id: fac.d_id, faculty_name: fac.faculty_name, 
                    contact_no: fac.contact_no, username: fac.username, 
                    specialization: fac.specialization, password: fac.password });
            })

        } else {
            return
        }

    }

    cancel() {
        this.props.history.push('/admin');
    }


    render() {
        return (
            <Fragment>
                <Row>
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>
                        <Form>
                            <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Faculty Details</h3>
                            <Row form>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Select Department</Label>
                                        <Input type="select" value={this.state.d_id}
                                            onChange={this.changeDeptNameHandler} >
                                            {
                                                this.state.departments.map(
                                                    department =>
                                                        <option key={department.dept_id}>{department.dept_name}</option>
                                                )
                                            }
                                        </Input>
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Name</Label>
                                        <Input type="text" value={this.state.faculty_name}
                                            onChange={this.changeFacultyNameHandler} placeholder="Enter Full Name" />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row form>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Contact No</Label>
                                        <Input type="number" value={this.state.contact_no}
                                            onChange={this.changeContactHandler} placeholder="Enter Mobile Number" />
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Email-Address</Label>
                                        <Input type="text" value={this.state.username}
                                            onChange={this.changeUsernameHandle} placeholder="Enter Personal Email address"
                                        />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row form>

                                <Col md={12}>
                                    <FormGroup>
                                        <Label for="">Specialization in</Label>
                                        <Input type="textarea" value={this.state.specialization}
                                            onChange={this.changeSpecHandler} placeholder="Enter Details" />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row form>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Create Username</Label>
                                        <Input type="email" value={this.state.email}
                                            onChange={this.changeEmailHandler} placeholder="Enter Username" />
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Password</Label>
                                        <Input type="password" value={this.state.password}
                                            onChange={this.changePasswordHandler} placeholder="Enter Password" />
                                    </FormGroup>
                                </Col>

                            </Row>


                            <Container className="text-center" >
                                <Button onClick={this.saveOrUpdateFaculty} color="success">Save</Button>
                                <Button onClick={this.cancel.bind(this)} color="danger ml-2">Cancel</Button>
                            </Container>
                        </Form>



                    </Col>
                </Row>
                <Row>
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>
                        <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Edit-Details</h3>

                        <Table className="text-center" responsive striped hover bordered size="sm">
                            <thead>
                                <tr>

                                    <th>Name</th>
                                    <th>Department</th>
                                    <th>Contact</th>
                                    <th>Username</th>
                                    {/* <th>Edit</th> */}
                                    <th>Delete</th>

                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.faculties.map(
                                        faculty =>
                                            <tr key={faculty.faculty_id}>
                                                <td>{faculty.faculty_name}</td>
                                                <td>{faculty.d_id}</td>
                                                <td>{faculty.contact_no}</td>
                                                <td>{faculty.username}</td>
                                                {/* <td><Button onClick={() => this.editFaculty(faculty.faculty_id)} color="info">Edit</Button></td> */}
                                                <td><Button onClick={() => this.deleteFaculty(faculty.faculty_id)} color="info">Delete</Button></td>

                                            </tr>

                                    )
                                }
                            </tbody>
                        </Table>
                    </Col>
                </Row>
            </Fragment>
        );
    }
}

export default add_faculty;