import React, { Fragment, Component } from "react";
import { Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from "reactstrap";
import subjectService from "../../services/subject";
import courseService from "../../services/course";
import departmentService from "../../services/department";
import { toast, Flip } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

class add_subjects extends Component {

    constructor(props) {
        super(props);

        this.state = {
            //TO GET ID FROM URL (params)
            id: this.props.match.params.id,

            //TO GET ALL COURSES
            courses: [],
            // courses: [{ id: '1', name: 'BCA' },
            // { id: '2', name: 'MCA' },
            // { id: '3', name: 'BBA' },],

            //TO GET ALL DEPT DEATAILS TO DISPLAY
            departments: [],
            // departments: [{ deptId: '1', name: 'computer' },
            // { deptId: '2', name: 'BE' },
            // { deptId: '3', name: 'ME' },],

            //TO GET ALL SUBJCETS
            // subjects: [],
            subjects:[{id:'1',name:'JAVA',c_id:'BCA',deptId:'Computer',units:'10'},
            {id:'2',name:'ADJAVA',c_id:'BCA',deptId:'Computer',units:'20'},],

            //TO GET SUBJECTS DETAILS ONE BY ONE ON FORM
            name: '',
            c_id: '',
            deptId: '',
            units: ''

        }
        //BINDING ALL THE EVENTS
        this.changeDeptNameHandler = this.changeDeptNameHandler.bind(this);
        this.changeCourseNameHandler = this.changeCourseNameHandler.bind(this);
        this.changeSubjectNameHandler = this.changeSubjectNameHandler.bind(this);
        this.changeUnitsHandler = this.changeUnitsHandler.bind(this);

        //FOR BUTTONS
        this.saveOrUpdateSubject = this.saveOrUpdateSubject.bind(this);
        this.editSubject = this.editSubject.bind(this);
        this.deleteSubject = this.deleteSubject.bind(this);

    }

    //TO GET ALL DEPARTMENTS:-  
    componentDidMount() {
        departmentService.getDeparments().then((res) => {
            this.setState({ departments: res.data.result });
        })
         //TO GET ALL COURSES:-
        courseService.getCourses().then((res) => {
            this.setState({ courses: res.data.result });
        })
          //TO GET ALL SUBJECTS:- 
        subjectService.getSubjects().then((res) => {
            this.setState({ subjects: res.data.result });
        })
    }


    //EVENT HANDLER TO FILL THE DATA IN FIELD
    changeDeptNameHandler = (event) => {
        this.setState({ deptId: event.target.value });

    }
    changeCourseNameHandler = (event) => {
        this.setState({ c_id: event.target.value });

    }
    changeSubjectNameHandler = (event) => {
        this.setState({ name: event.target.value });

    }
    changeUnitsHandler = (event) => {
        this.setState({ units: event.target.value });

    }

    //TO SAVE THE FORM DATA
    saveOrUpdateSubject = (e) => {
        e.preventDefault();
        let subj = {
            deptId: this.state.deptId, c_id: this.state.c_id, name: this.state.name,
            units: this.state.units
        };

        //TO PRINT DATA ON CONSOLE
        console.log('subj =>' + JSON.stringify(subj));

        if (this.state.id > 0) {
            //TO UPDATE THE DATA FROM SUBJECT_ID
            subjectService.updateSubjectByID(subj, this.state.id).then((res) => {
                this.props.history.push('/admin/add_subject');

            })

        } else {
            //TO SAVE/CREATE DATA TO SERVER
            subjectService.createSubject(subj).then((res) => {
                this.props.history.push('/admin/add_subject');
            })

        }

    }

    //EVENT TO GET COURSE DETAIL BY ID
    editSubject(id) {
        this.props.history.push(`/admin/add_subject/${id}`);
    }

    //EVENT TO DELETE COURSE DETAIL BY ID
    deleteSubject(id) {
        subjectService.deleteSubjectByID(id).then((res) => {
            //JUST FILTERING DEPT ARRAY DATA
            this.props.history.push("/admin");
            // alert("Deleted Successfully...");
            toast.error('Deleted SuccessFully...', {
                position: "top-center",
                autoClose: 3000,
                transition: Flip,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: false,
                draggable: true,
                progress: undefined,
              });
            this.setState({ subjects: this.state.subjects.filter(subj => subj.id !== id) });
        })

    }

     //TO UPDATE FORM DATA FROM COURSE ID
     componentDidMount() {
        if (this.state.id > 0) {
            subjectService.getSubjectByID(this.state.id).then((res) => {
                let subj = res.data;
                this.setState({ deptId: subj.deptId,c_id: subj.c_id,name: subj.name,units: subj.units});
            })

        } else {
            return
        }

    }

    cancel() {
        this.props.history.push('/admin/add_subject');
    }



    render() {
        return (
            <Fragment>
                <Row>
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>
                        <Form>
                            <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Subjects</h3>
                            <Row form>
                                <Col md={6}>
                                    <FormGroup>

                                        <Label for="">Select Department</Label>
                                        <Input type="select" value={this.state.deptId}
                                            onChange={this.changeDeptNameHandler}>
                                            {
                                                this.state.departments.map(
                                                    department =>
                                                        <option key={department.deptId}>{department.name}</option>
                                                )
                                            }
                                        </Input>
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Select Courses</Label>
                                        <Input type="select" value={this.state.c_id}
                                            onChange={this.changeCourseNameHandler}>
                                            {
                                                this.state.courses.map(
                                                    course =>
                                                        <option key={course.id}>{course.name}</option>
                                                )
                                            }
                                        </Input>
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row form>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Subject Name</Label>
                                        <Input type="text" value={this.state.name}
                                            onChange={this.changeSubjectNameHandler} placeholder="Enter Subject Name" />
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">No Of Units / Chapters</Label>
                                        <Input type="number" value={this.state.units}
                                            onChange={this.changeUnitsHandler} placeholder="Enter Value" />
                                    </FormGroup>
                                </Col>
                            </Row>


                            <Container className="text-center" >
                                <Button onClick={this.saveOrUpdateSubject} color="success">Save</Button>
                                <Button onClick={this.cancel.bind(this)} color="danger ml-2">Cancel</Button>
                            </Container>
                        </Form>
                    </Col>
                </Row>

                <Row>
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>
                        <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Edit-Details</h3>

                        <Table className="text-center" striped hover bordered size="sm">
                            <thead>
                                <tr>

                                    <th>Subject</th>
                                    <th>Department</th>
                                    <th>Course</th>
                                    <th>Units</th>
                                    {/* <th>Edit</th> */}
                                    <th>Delete</th>

                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.subjects.map(
                                        subject =>
                                            <tr key={subject.id}>
                                                <td>{subject.name}</td>
                                                <td>{subject.deptId}</td>
                                                <td>{subject.c_id}</td>
                                                <td>{subject.units}</td>
                                                {/* <td><Button onClick={() => this.editSubject(subject.id)} color="info">Edit</Button></td> */}
                                                <td><Button onClick={() => this.deleteSubject(subject.id)} color="info">Delete</Button></td>


                                            </tr>

                                    )
                                }

                            </tbody>
                        </Table>
                    </Col>
                </Row>
            </Fragment >
        );
    }
}

export default add_subjects;