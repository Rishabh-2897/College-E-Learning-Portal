import React, {Component } from "react";
import { Link } from "react-router-dom";
import EmailIcon from '@material-ui/icons/Email';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';


import {
    Collapse,
    Navbar,
    NavbarToggler,
    NavbarBrand,
    Nav,
    NavItem,
    NavLink,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    NavbarText
} from "reactstrap";


class admin_navbar extends Component {

    constructor(props) {
        super(props);

        this.state = {
                
        }

    }


    render() {
        return (
            <div>
            <Navbar className="mt-2" style={{ backgroundColor: "#94ffae" }} light expand="md">

                <NavbarBrand style={{fontSize:"22px"}}>Welcome Admin</NavbarBrand>

                <NavbarToggler />
                <Collapse navbar>
                    <Nav className="mr-auto" navbar>

                        <NavItem style={{ fontSize: "20px" }}>
                            <NavLink>
                                <Link style={{ textDecoration: "none", color: "grey" }} to="/admin/inbox"><EmailIcon fontSize="default" /> Inbox</Link>
                            </NavLink>
                        </NavItem>
                       
                        <NavItem style={{ fontSize: "20px" }}>
                            <NavLink>
                                <Link style={{ textDecoration: "none", color: "grey" }} to="/admin/acc_approve">New-Accounts</Link>
                            </NavLink>
                        </NavItem>

                        <NavItem style={{ fontSize: "20px" }}>
                            <NavLink>
                                <Link style={{ textDecoration: "none", color: "grey" }} to="/admin/class_info">Class-Info</Link>
                            </NavLink>
                        </NavItem>
                        
                        <UncontrolledDropdown nav inNavbar>
                            <DropdownToggle style={{ fontSize: "20px",color: "grey" }} nav caret>
                                More
                            </DropdownToggle>
                            <DropdownMenu className="text-center">
                                <DropdownItem>
                                <Link style={{ textDecoration: "none",color:"black"}} to="/admin/change_password">Change Password</Link>
                                </DropdownItem>
                                <DropdownItem divider />
                                <DropdownItem style={{color:"white"}} className="bg-danger">
                                <a style={{ textDecoration: "none", color: "white" }} href="http://localhost:3000/">Logout</a>
                                </DropdownItem>

                            </DropdownMenu>
                        </UncontrolledDropdown>
                    </Nav>
                    <NavbarText style={{ fontSize: "20px" }}><AccountCircleIcon fontSize="default" /> (Admin Name)</NavbarText>
                </Collapse>
            </Navbar>


        </div>
        );
    }
}

export default admin_navbar;
        
