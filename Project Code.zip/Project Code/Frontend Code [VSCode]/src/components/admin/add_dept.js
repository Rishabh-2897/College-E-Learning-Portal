import React, { Fragment, Component } from "react";
import { Form, FormGroup, Input, Container, Button, Col, Row, Table } from "reactstrap";
import departmentService from "../../services/department";


class add_dept extends Component {

    constructor(props) {
        super(props)

        this.state = {
            //TO GET ID FROM URL (params)
            id: this.props.match.params.id,

            //TO GET ALL DEPT DEATAILS TO DISPLAY ON TABLE
            departments : [],
           /* departments: [{deptId:'1',name:'computer'},
            {deptId:'2',name:'BE'},
            {deptId:'3',name:'ME'}],
*/
            //TO GET DEPT DETAILS ONE BY ONE ON FORM
            // & TO SEND TO DB IN JSON FORMAT 
            name: '',

        }
        //BINDING ALL THE EVENTS
        this.changeDeptNameHandler = this.changeDeptNameHandler.bind(this);
        this.saveOrUpdateDept = this.saveOrUpdateDept.bind(this);
        this.editDept = this.editDept.bind(this);
        this.deleteDept = this.deleteDept.bind(this);


    }

    //TO GET ALL DEPARTMENTS:- 
   
    componentWillMount() {
        document.title = "Add Department";
        departmentService.getDeparments().then((res) => {
           this.setState({ departments : res.data.result});
          //console.log(JSON.stringify(res.data.result));
                   
        })
    }

    //EVENT HANDLER TO FILL THE DATA IN FIELD
    changeDeptNameHandler = (event) => {
        this.setState({ name: event.target.value });

    }

    //TO SAVE THE FORM DATA
    saveOrUpdateDept = (e) => {
        e.preventDefault();
        let dept = { name: this.state.name };

        //TO PRINT DATA ON CONSOLE
        console.log('dept =>' + JSON.stringify(dept));

        if (this.state.id > 0) {
            //TO UPDATE THE DATA FROM deptId
            departmentService.updateDeparmentByID(dept, this.state.id).then((res) => {
                this.props.history.push('/admin/add_dept');

            })

        } else {
            //TO SAVE/CREATE DATA TO SERVER
            departmentService.createDeparment(dept).then((res) => {
                this.props.history.push('/admin/add_dept');
              
                alert("Departemnts Added SuccessFully"); 
            })

            departmentService.getDeparments().then((res) => {
              
                this.setState({ departments : res.data.result});
               // console.log(JSON.stringify(res.data.result));
                //  console.log(res.data.result[0]);
                this.props.history.push('/admin/add_dept');
                  alert("Loading Departemnts"); 
            })
        }

    }

    //EVENT TO GET DEPT DETAIL BY ID
    editDept(id) {
        this.props.history.push(`/admin/add_dept/${id}`);
    }

    //EVENT TO DELETE DEPT DETAIL BY ID
    deleteDept(id) {
        departmentService.deleteDeparmentByID(id).then((res) => {
            this.props.history.push("/admin/add_dept");
            alert("Deleted SuccessFully...");
            //JUST FILTERING DEPT ARRAY DATA
            this.setState({ departments: this.state.departments.filter(dept => dept.id !== id) });

            departmentService.getDeparments().then((res) => {
              
                this.setState({ departments : res.data.result});
               // console.log(JSON.stringify(res.data.result));
                //  console.log(res.data.result[0]);
                this.props.history.push('/admin/add_dept');
                  alert("Loading Departemnts"); 
            })
        })

    }  

    //TO UPDATE FORM DATA FROM DEPARTMENT ID
    // componentDidMount() {
    //     if (this.state.id > 0) {
    //         departmentService.getDeparmentByID(this.state.id).then((res) => {
    //             let dept = res.data.result[this.state.id];
    //             console.log(res.data.result[this.state.id]);
    //             this.setState({ name: dept.dept_name});
    //             alert("In update method");
    //         })

    //     } else {
    //         return
    //     }

    // }

    
    cancel() {
        this.props.history.push('/admin');
    }

    getTitle() {
        if (this.state.id > 0) {
            return <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>
                Update Department</h3>

        }
        else {
            return <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>
                New Department</h3>
        }
    }
   
    render() {
       
        return (
            <Fragment>
                <Row>
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>
                        <Form>
                            {
                                this.getTitle()
                            }
                            <Row form>
                                <Col md={4}></Col>
                                <Col md={4}>
                                    <FormGroup className="pt-2">
                                        <Input type="text" value={this.state.name}
                                            onChange={this.changeDeptNameHandler} placeholder="Enter Department Name" />
                                    </FormGroup>
                                    <Container className="text-center" >
                                        <Button onClick={this.saveOrUpdateDept} color="success">Save</Button>
                                        <Button onClick={this.cancel.bind(this)} color="danger ml-2">Cancel</Button>
                                    </Container>
                                </Col>

                            </Row>



                        </Form>


                    </Col>
                </Row>
                <Row>
                    <Col md={1}>
                    </Col>

                    <Col className="m-3" md={8}>
                        <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Edit-Details</h3>

                        <Table className="text-center" striped hover bordered size="sm">
                            <thead>
                                <tr>

                                    <th>Department</th>
                                    {/* <th>Edit</th> */}
                                    <th>Delete</th>

                                </tr>
                            </thead>
                            <tbody>

                                {
                                    this.state.departments.map(
                                        department =>
                                            <tr key={department.deptId}>
                                                <td>{department.name}</td>
                                                {/* <td><Button onClick={() => this.editDept(department.deptId)} color="info">Edit</Button></td> */}
                                                <td><Button onClick={() => this.deleteDept(department.deptId)} color="info">Delete</Button></td>
                                            </tr>

                                    )
                                }

                            </tbody>
                        </Table>
                    </Col>
                </Row>
            </Fragment>
        );
    }
}

export default add_dept;