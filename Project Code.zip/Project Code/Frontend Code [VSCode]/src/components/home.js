import React, { Component } from 'react';
import { BrowserRouter as Router, Link, Route } from "react-router-dom";
import { UncontrolledButtonDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap';

class home extends Component {
    constructor(props) {
        super(props)

        this.state = {

        }

    }
    render() {
        return (
            <div className="text-center p-3">
                <UncontrolledButtonDropdown >
                    <DropdownToggle color="outline-info" caret>
                        Login Here
                    </DropdownToggle>
                    <DropdownMenu>
                        <DropdownItem>
                            <Link to="/student/login" className="btn btn-outline-success ml-2">Login As Student</Link>
                        </DropdownItem>
                        <DropdownItem divider />
                        <DropdownItem>
                            <Link to="/faculty/login" className="btn btn-outline-success ml-2">Login As Faculty</Link>
                        </DropdownItem>
                        <DropdownItem divider />
                        <DropdownItem>
                            <Link to="/admin/login" className="btn btn-outline-success ml-2">Login As Admin</Link>
                        </DropdownItem>
                    </DropdownMenu>
                </UncontrolledButtonDropdown>





                {/* <Link to="/login" className="btn btn-outline-success">Login Here</Link> */}
                <Link to="/registration" className="btn btn-outline-info ml-2">Register Here</Link>
            </div>

        );
    }
}

export default home;
