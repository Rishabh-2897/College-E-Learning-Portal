import React, { Fragment, Component } from "react";
import { Form, Col, Row, Table } from 'reactstrap';
import { Link } from "react-router-dom";
import messageService from "../services/message";

class inbox extends Component {
    constructor(props) {
        super(props);

        this.state = {
            messages: [],
        }

    }

    //TO GET ALL MESSAGES:-  
    componentWillMount() {
        document.title = "Inbox Messages";
        messageService.getMessages().then((res) => {
            this.setState({ messages: res.data.result });
            // console.log(JSON.stringify(res.data.result));
            //  console.log(res.data.result[0]);

            alert("Loading Messages");
        })
    }

    render() {
        return ( <
            Fragment >
            <
            Row >
            <
            Col md = { 1 } >
            <
            /Col> <
            Col md = { 9 } >
            <
            Form >
            <
            Col >
            <
            Link className = "btn btn-outline-info mt-1 mb-2"
            to = "./compose" > Compose Message < /Link> <
            h3 className = "bg-info p-2"
            style = {
                { color: "white" } } > Inbox < /h3>

            <
            Table className = "text-center"
            responsive striped hover bordered size = "sm" >
            <
            thead >
            <
            tr >

            <
            th className = "pb-3" > Message Body < /th>


            <
            /tr> <
            /thead> <
            tbody > {
                this.state.messages.map(
                    mesage =>
                    <
                    tr key = { mesage.id } >
                    <
                    td > { mesage.text } < /td>

                    <
                    /tr>

                )
            }

            <
            /tbody> <
            /Table> <
            /Col>

            <
            /Form> <
            /Col> <
            /Row>


            <
            /Fragment>

        );
    }
}

export default inbox;