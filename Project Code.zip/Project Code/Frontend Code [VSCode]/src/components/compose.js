import React, { Fragment,Component } from "react";
import { Form, FormGroup, Label, Input, Container, Button, Col, Row } from 'reactstrap';
import messageService from "../services/message";
import { toast, Flip } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

class compose extends Component {

    constructor(props) {
        super(props);

        this.state = {
            //TO GET TEXT DETAILS ONE BY ONE ON FORM
            text: ''

        }
        //BINDING ALL THE EVENTS
        this.changeTextHandler = this.changeTextHandler.bind(this);
        this.saveOrUpdateMsg = this.saveOrUpdateMsg.bind(this);

    }

     //EVENT HANDLER TO FILL THE DATA IN FIELD
     changeTextHandler = (event) => {
        this.setState({ text: event.target.value });

    }

    //TO SAVE THE FORM DATA
    saveOrUpdateMsg = (e) => {
        e.preventDefault();
        let txt = { text: this.state.text };

        //TO PRINT DATA ON CONSOLE
        console.log('txt =>' + JSON.stringify(txt));

        //TO SAVE/CREATE DATA TO SERVER
        messageService.createMessages(txt).then((res) => {
            this.props.history.push('./inbox');
            // alert("Message Sent To All ...");
            toast.success('Message Sent To All ...', {
                position: "top-center",
                autoClose: 3000,
                transition: Flip,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: false,
                draggable: true,
                progress: undefined,
              });
        })

    }



    cancel() {
        this.props.history.push('/admin');
    }

    render() {
        return (
            <Fragment>
                <Row>
                    <Col md={2}>
                    </Col>
                    <Col className="m-1" md={6}>
                        <Form>
                            <Row form>
                                <Col>
                                    <h3 className="bg-info p-2" style={{ color: "white" }}>Compose Message</h3>
                                    <FormGroup>
                                        <Label for="">Type Message Here :</Label>
                                        <Input type="textarea" rows="5" value={this.state.text}
                                            onChange={this.changeTextHandler} placeholder="Enter Your Text Here ..." />
                                    </FormGroup>
                                    <Container className="text-center" >
                                        <Button onClick={this.saveOrUpdateMsg} color="success">Send</Button>
                                        <Button onClick={this.cancel.bind(this)} color="danger ml-2">Cancel</Button>
                                    </Container>
                                </Col>

                            </Row>

                        </Form>
                    </Col>
                </Row>

            </Fragment>
        );
    }
}

export default compose;
