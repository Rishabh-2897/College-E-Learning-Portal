import React from "react";

function Header({pg_name})
{
    return(
        <div className="text-center">
            <h2>E-Learnig Portal</h2>
            <h3>{pg_name}</h3>
        </div>
    )
}

export default Header;