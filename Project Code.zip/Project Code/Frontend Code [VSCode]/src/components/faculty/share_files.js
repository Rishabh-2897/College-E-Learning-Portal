import React, { Fragment, Component } from "react";
import { Form, FormGroup, Label, Input, Container, Button, Col, Row, Table, CustomInput } from "reactstrap";
import docsService from "../../services/sharedoc";
class share_files extends Component {

    constructor(props) {
        super(props);

        this.state = {
            //TO GET ID FROM URL (params)
            id: this.props.match.params.id,

            //TO GET ALL FILES DEATAILS TO DISPLAY
            sharedocs: [],

            name: '' 
        }
        //BINDING ALL THE EVENTS
        this.changeFileHandler = this.changeFileHandler.bind(this);
        this.saveOrUpdateFile = this.saveOrUpdateFile.bind(this);
        // this.editFile = this.editFile.bind(this);
        this.deleteFile = this.deleteFile.bind(this);

    }
    //TO GET ALL SHARE DOCUMENTS/FILES:-  
    componentWillMount() {
        document.title = "Share Files";
        // docsService.getFiles().then((res) => {
        //     this.setState({ sharedocs: res.data.result});
        // })
    }

     //EVENT HANDLER TO FILL THE DATA IN FIELD
     changeFileHandler = (event) => {
        this.setState({ name: event.target.value });

    }

    //TO SAVE THE FORM DATA
    saveOrUpdateFile = (e) => {
        e.preventDefault();
        let fd = { name: this.state.name };

        //TO PRINT DATA ON CONSOLE
        console.log('fd =>' + JSON.stringify(fd));

        if (this.state.id > 0) {
            //TO UPDATE THE DATA FROM FILEID
            docsService.updateFileByID(fd, this.state.id).then((res) => {
                this.props.history.push('/faculty/share_files');

            })

        } else {
            //TO SAVE/CREATE DATA TO SERVER
            docsService.createFile(fd).then((res) => {
                this.props.history.push('/faculty/share_files');
              
                alert("File Send SuccessFully"); 
            })

            docsService.getFiles().then((res) => {
              
                this.setState({ sharedocs : res.data.result});
               // console.log(JSON.stringify(res.data.result));
                //  console.log(res.data.result[0]);
                this.props.history.push('/faculty/share_files');
                  alert("Loading Details"); 
            })
        }

    }


    //EVENT TO DELETE FILE DETAIL BY ID
    deleteFile(id) {
        docsService.deleteFileByID(id).then((res) => {
            this.props.history.push("/faculty/share_files");
            alert("Deleted SuccessFully...");
            //JUST FILTERING FILES ARRAY DATA
            this.setState({ sharedocs: this.state.sharedocs.filter(fd => fd.id !== id) });

            docsService.getFiles().then((res) => {
              
                this.setState({ sharedocs : res.data.result});
               // console.log(JSON.stringify(res.data.result));
                //  console.log(res.data.result[0]);
                this.props.history.push('/faculty/share_files');
                  alert("Loading Details..."); 
            })
        })

    }  

    cancel() {
        this.props.history.push('/faculty');
    }

    render() {
        return (
            <Fragment>
                <Row>
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>
                        <Form>
                            <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Share Files</h3>
                            <Row form>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Select Course</Label>
                                        <Input type="select" name="course" id="">
                                            <option>BCA</option>
                                            <option>MCA</option>
                                            <option>BBA</option>
                                            <option>MBA</option>

                                        </Input>
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Select Subject</Label>
                                        <Input type="select" name="subject" id="">
                                            <option>Java</option>
                                            <option>Account</option>
                                            <option>PHP</option>
                                            <option>AWP</option>

                                        </Input>
                                    </FormGroup>
                                </Col></Row>
                            <Row form>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Document Type</Label>
                                        <Input type="select" name="doc_type" id="">
                                            <option>Notes</option>
                                            <option>Syllabus</option>
                                            <option>Question Banks</option>
                                            <option>Read-Me</option>

                                        </Input>
                                    </FormGroup>
                                </Col>
                              
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Select File</Label>

                                        <CustomInput type="file"value={this.state.name}
                                            onChange={this.changeFileHandler} multiple />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Container className="text-center" >
                                <Button onClick={this.saveOrUpdateFile} color="outline-success">Send</Button>
                                <Button onClick={this.cancel.bind(this)} color="outline-danger ml-2">Reset</Button>
                            </Container>
                        </Form>

                    </Col>

                </Row>

                <Row>
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>

                        <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Upload History</h3>
                        <Table className="text-center" striped hover bordered size="sm">
                            <thead>
                                <tr>
                                    {/* <th>Course</th>
                                    <th>Subject</th>
                                    <th>Type</th> */}
                                    <th>File name</th>
                                    {/* <th>Edit</th> */}
                                    <th>Delete</th>

                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.sharedocs.map(
                                        sharedoc =>
                                            <tr key={sharedoc.id}>
                                                {/* <td>{sharedoc.s_id}</td>
                                                <td>{sharedoc.type}</td> */}
                                                <td>{sharedoc.file_name}</td>
                                                <td><Button onClick={() => this.deleteFile(sharedoc.id)} color="info">Delete</Button></td>

                                            </tr>

                                    )
                                }

                            </tbody>
                        </Table>
                    </Col>
                </Row>

            </Fragment>
        );
    }
}

export default share_files;
