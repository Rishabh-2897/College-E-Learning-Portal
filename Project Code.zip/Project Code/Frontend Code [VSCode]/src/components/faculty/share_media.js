import React, { Fragment, useEffect, useState, Component } from "react";
import { Link } from "react-router-dom";
import { Form, FormGroup, Label, Input, Container, Button, Col, Row, Table, CustomInput } from "reactstrap";

class share_media extends Component {

    constructor(props) {
        super(props);

        this.state = {
            sharemedias: []
        }

    }

    render() {
        return (
            <Fragment>
                <Row>
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>
                        <Form>
                            <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Share Media</h3>
                            <Row form>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Select Course</Label>
                                        <Input type="select" name="course" id="">
                                            <option>BCA</option>
                                            <option>MCA</option>
                                            <option>BBA</option>
                                            <option>MBA</option>

                                        </Input>
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Select Subject</Label>
                                        <Input type="select" name="subject" id="">
                                            <option>Java</option>
                                            <option>Account</option>
                                            <option>PHP</option>
                                            <option>AWP</option>

                                        </Input>
                                    </FormGroup>
                                </Col></Row>
                            <Row form>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Document Type</Label>
                                        <Input type="select" name="media_type" id="">
                                            <option>Session Recordings</option>
                                            <option>Guest Lectures</option>
                                        </Input>
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Select File</Label>

                                        <CustomInput type="file" name="file" id="" multiple />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Container className="text-center" >
                                <Button type="submit" color="outline-success">Send</Button>
                                <Button type="reset" color="outline-danger ml-2">Reset</Button>
                            </Container>
                        </Form>
                    </Col>
                </Row>

                <Row>
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>
                        <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Upload History</h3>
                        <Table className="text-center" striped hover bordered size="sm">
                            <thead>
                                <tr>
                                    <th>Course</th>
                                    <th>Subject</th>
                                    <th>Type</th>
                                    <th>File name</th>
                                    <th>Edit</th>
                                    <th>Delete</th>

                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.sharemedias.map(
                                        sharemedia =>
                                            <tr key={sharemedia.id}>
                                                <td>{sharemedia.s_id}</td>
                                                <td>{sharemedia.type}</td>
                                                <td>{sharemedia.file_name}</td>

                                            </tr>

                                    )
                                }

                            </tbody>
                        </Table>
                    </Col>
                </Row>

            </Fragment>
        );
    }
}

export default share_media;
