import React, { Fragment, useEffect, useState,Component } from "react";
import { ListGroup, ListGroupItem } from 'reactstrap';
import { Link } from "react-router-dom";
import EmailIcon from '@material-ui/icons/Email';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';

import {
    Form, FormGroup, Label, Input, Container, Button, Col, Row, Collapse,
    Navbar,
    NavbarToggler,
    NavbarBrand,
    Nav,
    NavItem,
    NavLink,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    NavbarText
} from "reactstrap";

class faculty_navbar extends Component {

    constructor(props) {
        super(props);

        this.state = {
        
        }

    }

    render() {
        return (
            <div>
            <Navbar className="mt-2" style={{ backgroundColor: "#94ffae" }} light expand="md">

                <NavbarBrand style={{fontSize:"22px"}}>Welcome Faculty</NavbarBrand>

                <NavbarToggler />
                <Collapse navbar>
                    <Nav className="mr-auto" navbar>

                        <NavItem style={{ fontSize: "20px" }}>
                            <NavLink>
                                <Link style={{ textDecoration: "none", color: "grey" }} to="/faculty/inbox"><EmailIcon fontSize="default" /> Inbox</Link>
                            </NavLink>
                        </NavItem>
                        <NavItem style={{ fontSize: "20px" }}>
                            <NavLink>
                                <Link style={{ textDecoration: "none", color: "grey" }} to="/faculty/class_info">Class-Info</Link>
                            </NavLink>
                        </NavItem>
                        <NavItem style={{ fontSize: "20px" }}>
                            <NavLink>
                                <Link style={{ textDecoration: "none", color: "grey" }} to="/faculty/attendance">Daily Attendance</Link>
                            </NavLink>
                        </NavItem>
                        
                        <UncontrolledDropdown nav inNavbar>
                            <DropdownToggle style={{ fontSize: "20px",color: "grey" }} nav caret>
                                More
                            </DropdownToggle>
                            <DropdownMenu className="text-center">
                                <DropdownItem>
                                <Link style={{ textDecoration: "none",color:"black"}} to="/faculty/change_password">Change Password</Link>
                                </DropdownItem>
                                <DropdownItem divider />
                                <DropdownItem>
                                <Link style={{ textDecoration: "none",color:"black"}} to="/faculty/edit_profile">Edit Profile</Link>
                                </DropdownItem>
                                <DropdownItem divider />
                                <DropdownItem style={{color:"white"}} className="bg-danger">
                                <a style={{ textDecoration: "none", color: "white" }} href="http://localhost:3000/login">Logout</a>

                                </DropdownItem>

                            </DropdownMenu>
                        </UncontrolledDropdown>
                    </Nav>
                    <NavbarText style={{ fontSize: "20px" }}><AccountCircleIcon fontSize="default" /> (Faculty Name)</NavbarText>
                </Collapse>
            </Navbar>


        </div>
        );
    }
}

export default faculty_navbar;
        
  