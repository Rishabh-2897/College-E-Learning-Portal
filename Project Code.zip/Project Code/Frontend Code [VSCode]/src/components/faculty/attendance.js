import React, { Fragment, useEffect, useState, Component } from "react";
import { ListGroup, ListGroupItem, Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from 'reactstrap';
import { Link } from "react-router-dom";
import studentService from "../../services/student";

class attendance extends Component {

    constructor(props) {
        super(props);

        this.state = {
            students: []
        }

    }

    //TO GET ALL STUDENTS:-  
    componentDidMount(){
        studentService.getStudents().then((res) =>{
            this.setState({students: res.data});
        })
    }

    render() {
        return (
            <Fragment>
                <Row className="m-1">
                    <Col md={1}>
                    </Col>
                    <Col md={10}>
                        <Form>
                            <h5 className="bg-info p-2" style={{ color: "white" }}>Today's Attendance</h5>
                            <Row Form>
                                <Col md={2}>
                                    <FormGroup>
                                        <Label>
                                            Select Course
                            </Label>
                                        <Input type="select" name="course" id="">
                                            <option>MBA</option>
                                            <option>MCA</option>
                                        </Input>
                                    </FormGroup>
                                </Col>
                                <Col md={2}>
                                    <FormGroup>
                                        <Label>
                                            Select Subject
                            </Label>
                                        <Input type="select" name="subject" id="">
                                            <option>AWP</option>
                                            <option>JAVA     </option>
                                        </Input>
                                    </FormGroup>
                                </Col>
                                <Col md={2}>
                                    <FormGroup>
                                        <Container className="text-center mt-4 p-1" >
                                            <Button type="submit" color="outline-info">Take Attendance</Button>

                                        </Container>
                                    </FormGroup>
                                </Col>

                            </Row>

                            <Table className="text-center" responsive striped hover bordered size="sm">
                                <thead>
                                    <tr>
                                        <th className="pb-3">Rollno.</th>
                                        <th className="pb-3">Name</th>
                                        <th><Button type="submit" color="danger">Absent</Button></th>


                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        this.state.students.map(
                                            std =>
                                                <tr key={std.student_id}>
                                                    <td>{std.student_id}</td>
                                                    <td>{std.student_name}</td>
                                                </tr>

                                        )
                                    }


                                </tbody>
                            </Table>

                        </Form>
                    </Col>
                </Row>


            </Fragment>
        );
    }
}

export default attendance;
