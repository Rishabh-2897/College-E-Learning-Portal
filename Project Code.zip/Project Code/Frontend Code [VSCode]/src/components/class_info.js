import React, { Fragment, useEffect, useState,Component } from "react";
import { ListGroup, ListGroupItem, Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from 'reactstrap';
import { Link } from "react-router-dom";
import studentService from "../services/student";


class class_info extends Component {

    constructor(props) {
        super(props);

        this.state = {
            students: []
        }

    }

     //TO GET ALL STUDENTS INFO:-  
     componentDidMount() {
       studentService.getStudents().then((res) =>{
           this.setState({students: res.data});
       })
     }

    render() {
        return (
            <Fragment>
                <Row >
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>
                        <Form>
                            <h3 className="bg-info p-2" style={{ color: "white" }}>Student Class Details</h3>
                            <Row Form>
                                <Col md={3}>
                                    <FormGroup>
                                        <Label>
                                            Select Department
</Label>
                                        <Input type="select" name="department" id="">
                                            <option>Diploma</option>
                                            <option>Engineering</option>
                                            <option>Management</option>
                                            <option>Computer</option>
                                            <option>11th / 12th</option>
                                        </Input>
                                    </FormGroup>
                                </Col>
                                <Col md={3}>
                                    <FormGroup>
                                        <Label>
                                            Select Course
</Label>
                                        <Input type="select" name="course" id="">
                                            <option>MBA</option>
                                            <option>MCA</option>
                                        </Input>
                                    </FormGroup>
                                </Col>
                                <Col md={4}>
                                    <FormGroup>
                                        <Label>
                                            Select Student Name
</Label>
                                        <Input type="select" className="" name="std_name" id="">
                                            <option>Ram</option>
                                            <option>Balram</option>
                                        </Input>
                                    </FormGroup>

                                </Col>
                                <Col md={1}>
                                    <Container className="text-center mt-4 p-1" >
                                        <Button type="submit" color="outline-info">Search</Button>

                                    </Container>
                                </Col>
                            </Row>

                            <Table className="text-center mt-2" responsive striped hover bordered size="sm">
                                <thead>
                                    <tr>

                                        <th>Name</th>
                                        <th>Department</th>
                                        <th>Course</th>
                                        <th>Contact</th>
                                        <th>View</th>
                                        <th>Edit</th>
                                        <th>Delete</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        this.state.students.map(
                                            clinfo =>
                                                <tr key={clinfo.student_id}>
                                                    <td>{clinfo.student_name}</td>
                                                    <td>{clinfo.d_id}</td>
                                                    <td>{clinfo.c_id}</td>
                                                    <td>{clinfo.contactno}</td>
                                                </tr>

                                        )
                                    }

                                </tbody>
                            </Table>

                        </Form>

                    </Col>
                </Row>

            </Fragment>
        );
    }
}

export default class_info;


