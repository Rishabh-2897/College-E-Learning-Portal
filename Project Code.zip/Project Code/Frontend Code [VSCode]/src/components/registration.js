import React, { Fragment, Component } from "react";
import { FormGroup, Form,Input,Label, Container, Button, Col, Row } from "reactstrap";
import { Link } from "react-router-dom";

import { toast, Flip } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import studentService from "../services/student";

const required = value => {
    if (!value) {
        return (
            <div className="alert alert-danger" role="alert">
                This field is required!
            </div>
        );
    }
};

class registration extends Component {

    constructor(props) {
        super(props);

        this.state = {

            d_id: '',
            c_id: '',
            name: '',
            email: '',
            contactno: '',
            address: '',
            username: '',
            password: '',
            cpassword: ''

        }

        // BINDING ALL EVENT ON FORM
        this.deptChange = this.deptChange.bind(this);
        this.courseChange = this.courseChange.bind(this);
        this.stdNameChange = this.stdNameChange.bind(this);
        this.contactChange = this.contactChange.bind(this);
        this.emailChange = this.emailChange.bind(this);
        this.addressChange = this.addressChange.bind(this);
        this.usernameChange = this.usernameChange.bind(this);
        this.passwordChange = this.passwordChange.bind(this);
        this.cfpasswordChange = this.cfpasswordChange.bind(this);
        this.saveStd = this.saveStd.bind(this);

    }

    deptChange = (event) => {
        this.setState({ d_id: event.target.value });
    }
    
    courseChange = (event) => {
        this.setState({ c_id: event.target.value });
    }
    stdNameChange = (event) => {
        this.setState({ name: event.target.value });
    }
    contactChange = (event) => {
        this.setState({ contactno: event.target.value });
    }
    emailChange = (event) => {
        this.setState({ email: event.target.value });
    }
    addressChange = (event) => {
        this.setState({ address: event.target.value });
    }
    usernameChange = (event) => {
        this.setState({ username: event.target.value });
    }
    passwordChange = (event) => {
        this.setState({ password: event.target.value });
    }
    cfpasswordChange = (event) => {
        this.setState({ cpassword: event.target.value });
    }

   
    
    saveStd = (e) => {
        e.preventDefault();
        //DEFINING ARRAY TO SEND TO DB
        let stdData = {
            d_id: this.state.d_id, c_id: this.state.c_id,
            name: this.state.name, contactno: this.state.contactno,
            email: this.state.email, address: this.state.address,
            username: this.state.username, password: this.state.password
        };

        //TO PRINT DATA ON CONSOLE
        console.log('Student =>' + JSON.stringify(stdData));

        if (this.state.password === this.state.cpassword) {
            studentService.createStudent(stdData).then((res) => {

                this.props.history.push('/');
                // alert("Registration Done SuccessFully");
                toast.success('Registration Done...', {
                    position: "top-center",
                    autoClose: 3000,
                    transition: Flip,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: false,
                    draggable: true,
                    progress: undefined,
                  });
            })
        }
        else {
            this.props.history.push('/registration');
            alert("Invalid Data... Password not Matching");

        }
    }

    cancel() {
        this.props.history.push('/');
    }




    render() {
        return (
            <Fragment>
                <Form className="mt-2">
                    <Row form>
                        <Col md={3}>
                        </Col>
                        <Col style={{ border: "4px solid #c2ffd1" }} className="mt-3 p-4" md={6}>


                            <h3 className="bg-primary p-2 text-center" style={{ color: "white" }}>Registration Panel</h3>

                            <Row form>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Select Department</Label>
                                        <Input type="select"
                                            value={this.state.d_id}
                                            onChange={this.deptChange}
                                        >
                                            <option value="12">Diploma</option>
                                            <option value="13">Engineering</option>
                                            <option value="15">Management</option>
                                            <option value="19">Computer</option>
                                            <option value="20">11th / 12th</option>
                                        </Input>
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Select Course</Label>
                                        <Input type="select"
                                            value={this.state.c_id}
                                            onChange={this.courseChange}>
                                            <option value="1">BE</option>
                                            <option value="2">BBA</option>
                                            <option value="3">BCA</option>
                                            <option value="4">MBA</option>
                                            <option value="5">MCA</option>
                                        </Input>
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row form>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label>Name</Label>
                                        <Input type="text"
                                            value={this.state.name}
                                            onChange={this.stdNameChange}
                                            placeholder="Enter Full Name" />
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label>Email-Address</Label>
                                        <Input type="email"
                                            value={this.state.email}
                                            onChange={this.emailChange}
                                            placeholder="Enter Personal Email address" />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row form>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Contact No</Label>
                                        <Input type="number"
                                            value={this.state.contactno}
                                            onChange={this.contactChange}
                                            placeholder="Enter Mobile Number" />
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Addresss</Label>
                                        <Input type="textarea"
                                            value={this.state.address}
                                            onChange={this.addressChange}
                                            placeholder="Enter Permanent Address" />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row form>
                                <Col md={4}>
                                    <FormGroup>
                                        <Label for="">Create Username</Label>
                                        <Input type="email"
                                            value={this.state.username}
                                            onChange={this.usernameChange}
                                            placeholder="Enter Username" />
                                    </FormGroup>
                                </Col>
                                <Col md={4}>
                                    <FormGroup>
                                        <Label for="">Password</Label>
                                        <Input type="password"
                                            value={this.state.password}
                                            onChange={this.passwordChange}
                                            placeholder="Enter Password" />
                                    </FormGroup>
                                </Col>
                                <Col md={4}>
                                    <FormGroup>
                                        <Label for="">Confirm-Password</Label>
                                        <Input type="password"
                                            value={this.state.cpassword}
                                            onChange={this.cfpasswordChange}
                                            placeholder="Retype password" />
                                    </FormGroup>
                                </Col>
                            </Row>


                            <Container className="text-center" >
                                <Button onClick={this.saveStd} color="success">Register</Button>
                                <Button onClick={this.cancel.bind(this)} color="danger ml-2">Cancel</Button>
                                <br /><br />
                                <Link to="/" action>Already have account ?</Link>
                            </Container>
                        </Col></Row>
                </Form>
            </Fragment>
        );
    }
}

export default registration;
