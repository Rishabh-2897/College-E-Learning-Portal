import './App.css';
import { Button, Container, Row, Col, Card, CardBody } from 'reactstrap';
//import { Container,Card, CardBody } from 'reactstrap';
import { ToastContainer, toast, Flip } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { BrowserRouter as Router, Link, Route } from "react-router-dom";

import Header from "./components/header";
import Login from './components/login';
import Std_register from './components/registration';
import home_menu from './components/home_menu';
import admin_menu from './components/admin/admin_menu';
import admin_navbar from './components/admin/admin_navbar';
import add_faculty from './components/admin/add_faculty';
import add_dept from './components/admin/add_dept';
import add_courses from './components/admin/add_courses';
import add_subjects from './components/admin/add_subjects';
import assign_class from './components/admin/assign_class';
import acc_aproval from './components/admin/acc_aproval';
import inbox from './components/inbox';
import compose from './components/compose';
import class_info from './components/class_info';
import change_password from './components/change_password';


import faculty_menu from './components/faculty/faculty_menu';
import faculty_navbar from './components/faculty/faculty_navbar';
import take_attendane from './components/faculty/attendance';
import share_files from './components/faculty/share_files';
import share_media from './components/faculty/share_media';
import update_status from './components/faculty/update_status';

import edit_profile from './components/faculty/edit_profile';
import study_materials from './components/student/study_materials';
import recordings from './components/student/recordings';
import std_edit_profile from './components/student/std_edit_profile';
import upload_doc from './components/student/upload_doc';
import view_material from './components/student/view_material';
import view_rec from './components/student/view_rec';
import student_menu from './components/student/student_menu';
import student_navbar from './components/student/student_navbar';
import status from './components/student/status';
import home from './components/home';
import inbox2 from './components/inbox2';
import home_menu2 from './components/home_menu2';



function App() {
  // const btntoregister = () =>
  //   toast.info('Welcome Students 😄', {
  //     position: "top-center",
  //     autoClose: 2000,
  //     transition: Flip,
  //     hideProgressBar: true,
  //     closeOnClick: true,
  //     pauseOnHover: false,
  //     draggable: true,
  //     progress: undefined,
  //   });

  return (

    <div className="m-2">
     
      {/* <Button onClick={btntologin} color="outline-success">Login Here</Button>
<Button className="ml-2" onClick={btntoregister} color="outline-primary">Register Here</Button> */}

      <Router>

        <header style={{ backgroundColor: "#6eff91", boxShadow: "0px 12px 8px -10px grey" }} className="p-1">

          <Header pg_name="IASCD, Akurdi (Pune)" />
          <Route path="/" component={home} exact />

        </header>
             
        <Route path="/admin/login" component={Login} exact />
        <Route path="/student/login" component={Login} exact />
        <Route path="/faculty/login" component={Login} exact />
        <Route path="/registration" component={Std_register} exact />

        <Route path="/admin" component={admin_navbar} exact />
        <Route path="/admin/add_faculty" component={admin_navbar} exact />
        <Route path="/admin/add_faculty/:id" component={admin_navbar} exact />
        <Route path="/admin/add_dept" component={admin_navbar} exact />
        <Route path="/admin/add_dept/:id" component={admin_navbar} exact />
        <Route path="/admin/add_course" component={admin_navbar} exact />
        <Route path="/admin/add_course/:id" component={admin_navbar} exact />
        <Route path="/admin/add_subject" component={admin_navbar} exact />
        <Route path="/admin/add_subject/:id" component={admin_navbar} exact />
        <Route path="/admin/assign_class" component={admin_navbar} exact />
        <Route path="/admin/assign_class/:id" component={admin_navbar} exact />
        <Route path="/admin/inbox" component={admin_navbar} exact />
        <Route path="/admin/compose" component={admin_navbar} exact />
        <Route path="/admin/class_info" component={admin_navbar} exact />
        <Route path="/admin/acc_approve" component={admin_navbar} exact />
        <Route path="/admin/change_password" component={admin_navbar} exact />

        <Route path="/faculty" component={faculty_navbar} exact />
        <Route path="/faculty/share_files" component={faculty_navbar} exact />
        <Route path="/faculty/share_media" component={faculty_navbar} exact />
        <Route path="/faculty/update_status" component={faculty_navbar} exact />
        <Route path="/faculty/shedule_exams" component={faculty_navbar} exact />
        <Route path="/faculty/inbox" component={faculty_navbar} exact />
        <Route path="/faculty/compose" component={faculty_navbar} exact />
        <Route path="/faculty/class_info" component={faculty_navbar} exact />
        <Route path="/faculty/change_password" component={faculty_navbar} exact />
        <Route path="/faculty/attendance" component={faculty_navbar} exact />
        <Route path="/faculty/edit_profile" component={faculty_navbar} exact />

        <Route path="/student" component={student_navbar} exact />
        <Route path="/student/inbox" component={student_navbar} exact />
       
        <Route path="/student/feedback" component={student_navbar} exact />
        <Route path="/student/study_material" component={student_navbar} exact />
        <Route path="/student/recordings" component={student_navbar} exact />
        <Route path="/student/syllabus_status" component={student_navbar} exact />
        <Route path="/student/exams" component={student_navbar} exact />
        <Route path="/student/change_password" component={student_navbar} exact />
        <Route path="/student/edit_profile" component={student_navbar} exact />
        <Route path="/student/upload_doc" component={student_navbar} exact />
        <Route path="/student/session_rec" component={student_navbar} exact />
        <Route path="/student/guest_lec" component={student_navbar} exact />
        <Route path="/student/notes" component={student_navbar} exact />
        <Route path="/student/question_bank" component={student_navbar} exact />
        <Route path="/student/assignment" component={student_navbar} exact />
        <Route path="/student/syllabus" component={student_navbar} exact />


        <Row>
          <Col md={2}>
          <Route path="/" component={home_menu2} exact />
            <Route path="/admin" component={admin_menu} exact />
            <Route path="/admin/add_faculty" component={admin_menu} exact />
            <Route path="/admin/add_faculty/:id" component={admin_menu} exact />
            <Route path="/admin/add_dept" component={admin_menu} exact />
            <Route path="/admin/add_dept/:id" component={admin_menu} exact />
            <Route path="/admin/add_course" component={admin_menu} exact />
            <Route path="/admin/add_course/:id" component={admin_menu} exact />
            <Route path="/admin/add_subject" component={admin_menu} exact />
            <Route path="/admin/add_subject/:id" component={admin_menu} exact />
            <Route path="/admin/assign_class" component={admin_menu} exact />
            <Route path="/admin/assign_class/:id" component={admin_menu} exact />
            <Route path="/admin/inbox" component={admin_menu} exact />
            <Route path="/admin/compose" component={admin_menu} exact />
            <Route path="/admin/class_info" component={admin_menu} exact />
            <Route path="/admin/change_password" component={admin_menu} exact />
            <Route path="/admin/acc_approve" component={admin_menu} exact />


            <Route path="/faculty" component={faculty_menu} exact />
            <Route path="/faculty/share_files" component={faculty_menu} exact />
            <Route path="/faculty/share_media" component={faculty_menu} exact />
            <Route path="/faculty/update_status" component={faculty_menu} exact />
            <Route path="/faculty/shedule_exams" component={faculty_menu} exact />
            <Route path="/faculty/inbox" component={faculty_menu} exact />
            <Route path="/faculty/compose" component={faculty_menu} exact />
            <Route path="/faculty/change_password" component={faculty_menu} exact />
            <Route path="/faculty/class_info" component={faculty_menu} exact />
            <Route path="/faculty/attendance" component={faculty_menu} exact />
            <Route path="/faculty/edit_profile" component={faculty_menu} exact />

            <Route path="/student" component={student_menu} exact />
            <Route path="/student/inbox" component={student_menu} exact />
            <Route path="/student/compose" component={student_menu} exact />
            <Route path="/student/feedback" component={student_menu} exact />
            <Route path="/student/study_material" component={student_menu} exact />
            <Route path="/student/recordings" component={student_menu} exact />
            <Route path="/student/syllabus_status" component={student_menu} exact />
            <Route path="/student/exams" component={student_menu} exact />
            <Route path="/student/change_password" component={student_menu} exact />
            <Route path="/student/edit_profile" component={student_menu} exact />
            <Route path="/student/upload_doc" component={student_menu} exact />
            <Route path="/student/select_sub" component={student_menu} exact />
            <Route path="/student/session_rec" component={student_menu} exact />
            <Route path="/student/guest_lec" component={student_menu} exact />
            <Route path="/student/notes" component={student_menu} exact />
            <Route path="/student/question_bank" component={student_menu} exact />
            <Route path="/student/assignment" component={student_menu} exact />
            <Route path="/student/syllabus" component={student_menu} exact />



          </Col>

          <Col md={10} className="p-0">
          <Route path="/" component={home_menu} exact />
            <Route path="/admin/add_faculty" component={add_faculty} exact />
            <Route path="/admin/add_faculty/:id" component={add_faculty} exact />
            <Route path="/admin/add_dept" component={add_dept} exact />
            <Route path="/admin/add_dept/:id" component={add_dept} exact />
            <Route path="/admin/add_course" component={add_courses} exact />
            <Route path="/admin/add_course/:id" component={add_courses} exact />
            <Route path="/admin/add_subject" component={add_subjects} exact />
            <Route path="/admin/add_subject/:id" component={add_subjects} exact />
            <Route path="/admin/assign_class" component={assign_class} exact />
            <Route path="/admin/assign_class/:id" component={assign_class} exact />
            <Route path="/admin/inbox" component={inbox} exact />
            <Route path="/admin/compose" component={compose} exact />
            <Route path="/admin/class_info" component={class_info} exact />
            <Route path="/admin/acc_approve" component={acc_aproval} exact />
            <Route path="/admin/change_password" component={change_password} exact />

            <Route path="/faculty/share_files" component={share_files} exact />
            <Route path="/faculty/share_media" component={share_media} exact />
            <Route path="/faculty/update_status" component={update_status} exact />
            {/* <Route path="/faculty/shedule_exams" component={Update_Status} exact /> */}
            <Route path="/faculty/inbox" component={inbox} exact />
            <Route path="/faculty/compose" component={compose} exact />
            <Route path="/faculty/change_password" component={change_password} exact />
            <Route path="/faculty/class_info" component={class_info} exact />
            <Route path="/faculty/attendance" component={take_attendane} exact />
            <Route path="/faculty/edit_profile" component={edit_profile} exact />

            <Route path="/student/inbox" component={inbox2} exact />
          
            <Route path="/student/study_material" component={study_materials} exact />
            <Route path="/student/recordings" component={recordings} exact />
            <Route path="/student/syllabus_status" component={status} exact />
            {/* <Route path="/student/exams" component={student_navbar} exact /> */}
            <Route path="/student/change_password" component={change_password} exact />
            <Route path="/student/edit_profile" component={std_edit_profile} exact />
            <Route path="/student/upload_doc" component={upload_doc} exact />
            <Route path="/student/session_rec" component={view_rec} exact />
            <Route path="/student/guest_lec" component={view_rec} exact />
            <Route path="/student/notes" component={view_material} exact />
            <Route path="/student/question_bank" component={view_material} exact />
            <Route path="/student/assignment" component={view_material} exact />
            <Route path="/student/syllabus" component={view_material} exact />



          </Col>
        </Row>

      </Router>

      <ToastContainer />
    </div>

  );
}

export default App;
