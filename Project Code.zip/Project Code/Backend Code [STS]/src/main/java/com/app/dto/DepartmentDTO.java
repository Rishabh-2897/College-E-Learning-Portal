package com.app.dto;

public class DepartmentDTO {
	
	private long deptId;
	private String name;
	public DepartmentDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DepartmentDTO(long deptId, String name) {
		super();
		this.deptId = deptId;
		this.name = name;
	}
	/**
	 * @return the deptId
	 */
	public long getDeptId() {
		return deptId;
	}
	/**
	 * @param deptId the deptId to set
	 */
	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "DepartmentDTO [deptId=" + deptId + ", name=" + name + "]";
	}

	
}
