package com.app.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exc.ResourceNotFoundException;
import com.app.dao.DepartmentRepository;
import com.app.dto.DepartmentDTO;
import com.app.pojo.Admin;
import com.app.pojo.AssignClass;
import com.app.pojo.Course;
import com.app.pojo.Department;
import com.app.pojo.Faculty;
import com.app.pojo.Student;
import com.app.pojo.Subject;

@Service
@Transactional
public class DepartmentServiceImpl implements DepartmentService{
	
	
	@Autowired
	private DepartmentRepository departmentRepo;
	
	public DepartmentServiceImpl() {}

	@Override
	public List<DepartmentDTO> getAllDepartments() {
		List<DepartmentDTO> list = new ArrayList<>();
		departmentRepo.findAll().forEach(d -> {
			DepartmentDTO dto = new DepartmentDTO();
			BeanUtils.copyProperties(d, dto);
			list.add(dto);
		});
		return list;
	}
	
	@Override
	public DepartmentDTO addDepartment(Department department) {
		// invoke dao's method for persistence
		Department persistentDepartment = departmentRepo.save(department);
		// for sending response copy persistent user details ---> user dto(so that you
		// can control what all to share with the front end)
		DepartmentDTO dto = new DepartmentDTO();
		BeanUtils.copyProperties(persistentDepartment, dto);
		return dto;
	}// rets a dto  to the caller.

	

	@Override
	public String deleteDepartment(long departmentId) {
		//below method rets persistent user of exists or throws exc
		Department department = departmentRepo.findById(departmentId).orElseThrow(() -> new ResourceNotFoundException("Invalid Department ID"));
		departmentRepo.deleteById(departmentId);
		return "Department details for ID "+departmentId+" deleted...";

	}

	@Override
	public DepartmentDTO getDepartment(long departmentId) {
		Department department = departmentRepo.findById(departmentId).orElseThrow(() -> new ResourceNotFoundException("Invalid Department ID"));
		DepartmentDTO departmentDTO = new DepartmentDTO();
		BeanUtils.copyProperties(department, departmentDTO);
		System.out.println("department" + department);
		System.out.println("department DTO  " + departmentDTO);
		return departmentDTO;
	}

	@Override
	public DepartmentDTO updateDepartment(long departmentId, DepartmentDTO departmentDTO) {
		System.out.println("in update " + departmentId+" " +departmentDTO);
		// fetch exsiting details from the db
		Department departmentdetails= departmentRepo.findById(departmentId).get();
		System.out.println("department from db " + departmentdetails);
		// => userDetails : PERSISTENT POJO
		// copy updated user details coming from request payload ---> User details
		BeanUtils.copyProperties(departmentDTO, departmentdetails);
		departmentdetails.setDeptId(departmentId);
		departmentDTO.setDeptId(departmentId);
		departmentRepo.save(departmentdetails);
		System.out.println("updated department dtls " + departmentdetails);
		// modified state of persistent POJO
		return departmentDTO;
	}
	

}
