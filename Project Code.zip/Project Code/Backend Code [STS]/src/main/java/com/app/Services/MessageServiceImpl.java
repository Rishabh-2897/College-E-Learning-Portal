package com.app.Services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exc.ResourceNotFoundException;
import com.app.dao.MessageRepository;
import com.app.dto.MessageDTO;
import com.app.pojo.Message;
@Service
@Transactional
public class MessageServiceImpl implements MessageService {
	@Autowired
	private MessageRepository messageRepo;
	
	   @Override
		public Message addMessage(Message message) {
			messageRepo.save(message);
			return message;
			
		}


		@Override
		public List<MessageDTO> getAllMessage() {
			List<MessageDTO> list = new ArrayList<>();
			messageRepo.findAll().forEach(m -> {
				MessageDTO dto = new MessageDTO();
				BeanUtils.copyProperties(m, dto);
				list.add(dto);
			});
			return list;
		}
	


		@Override
		public String deleteMessagedetails(long messageId) {
			//below method rets persistent user of exists or throws exc
			Message message = messageRepo.findById(messageId).orElseThrow(() -> new ResourceNotFoundException("Invalid message ID"));
			messageRepo.deleteById(messageId);
			return "Message details for ID "+messageId+" deleted...";

		}
	}



	
	
	

