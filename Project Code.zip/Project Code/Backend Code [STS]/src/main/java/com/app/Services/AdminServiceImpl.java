package com.app.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exc.ResourceNotFoundException;
import com.app.dao.AdminRepository;
import com.app.dto.AdminDTO;
import com.app.dto.AssignClassDTO;
import com.app.dto.CourseDTO;
import com.app.dto.DepartmentDTO;
import com.app.dto.FacultyDTO;
import com.app.dto.SubjectDTO;
import com.app.pojo.Admin;
import com.app.pojo.AssignClass;
import com.app.pojo.Course;
import com.app.pojo.Department;
import com.app.pojo.Faculty;
import com.app.pojo.Subject;



@Service
@Transactional // Optional :Add it --- if you want to keep tx open in the service layer
public class AdminServiceImpl implements AdminService {
	// dependency : DAO layer i/f
	@Autowired
	private AdminRepository adminRepo;
	
	@Override
	public String deleteAdminDetails(long adminId) {
		//below method rets persistent user of exists or throws exc
				Admin admin = adminRepo.findById(adminId).orElseThrow(() -> new ResourceNotFoundException("Invalid User ID"));
				adminRepo.deleteById(adminId);
				return "Admin details for ID "+adminId+" deleted...";

	}


	@Override
	public Optional<Admin> getAdminById(Long adminId) {
		return adminRepo.findById(adminId);
	}

	@Override
	public Admin addAdmin(Admin admin) {
		adminRepo.save(admin);
		return admin;
		
	}

	@Override
	public Admin updateAdmin(long aid, Admin a) {
		// validate if faculty exists
				Optional<Admin> optionalAdmin=adminRepo.findById(aid);
				Admin admin=optionalAdmin.orElseThrow(null);
				return adminRepo.save(a);
		
	}
	
	
	}
