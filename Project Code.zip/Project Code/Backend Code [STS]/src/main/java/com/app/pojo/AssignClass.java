package com.app.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Assign_class")
public class AssignClass {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(length = 10)
	private int Status;
	@Column(length=50)
	private int Totalnoofunits;
	@ManyToOne
	@JoinColumn(name="d_id",nullable=false)
	private Department chosenDepartment;
	
	@ManyToOne
	@JoinColumn(name="c_id",nullable=false)
	private Course chosenCourse;
	
	@ManyToOne
	@JoinColumn(name="f_id",nullable=false)
	private Faculty chosenFaculty;
	
	@ManyToOne
	@JoinColumn(name="sub_id",nullable=false)
	private Subject chosenSubject;
	
	public AssignClass() {
		super();
		// TODO Auto-generated constructor stub
	}




	public AssignClass(long id, int status, Department chosenDepartment, Course chosenCourse, Faculty chosenFaculty,
			Subject chosenSubject) {
		super();
		this.id = id;
		Status = status;
		this.chosenDepartment = chosenDepartment;
		this.chosenCourse = chosenCourse;
		this.chosenFaculty = chosenFaculty;
		this.chosenSubject = chosenSubject;
	}


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getStatus() {
		return Status;
	}

	public void setStatus(int status) {
		Status = status;
	}

	public Department getChosenDepartment() {
		return chosenDepartment;
	}

	public void setChosenDepartment(Department chosenDepartment) {
		this.chosenDepartment = chosenDepartment;
	}

	public Course getChosenCourse() {
		return chosenCourse;
	}

	public void setChosenCourse(Course chosenCourse) {
		this.chosenCourse = chosenCourse;
	}

	public Faculty getChosenFaculty() {
		return chosenFaculty;
	}

	public void setChosenFaculty(Faculty chosenFaculty) {
		this.chosenFaculty = chosenFaculty;
	}

	public Subject getChosenSubject() {
		return chosenSubject;
	}

	public void setChosenSubject(Subject chosenSubject) {
		this.chosenSubject = chosenSubject;
	}

	@Override
	public String toString() {
		return "AssignClass [id=" + id +  ", Status="	+ Status + "]";
	}

}
