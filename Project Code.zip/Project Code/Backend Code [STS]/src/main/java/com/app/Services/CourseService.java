package com.app.Services;

import java.util.List;
import java.util.Optional;

import com.app.dto.CourseDTO;
import com.app.pojo.AssignClass;
import com.app.pojo.Course;
import com.app.pojo.SharedFiles;
import com.app.pojo.Student;
import com.app.pojo.Subject;

public interface CourseService {
	

public List<CourseDTO>getAllCourses();

CourseDTO addCourse(Course course);
String deleteCourse(long   courseId);
CourseDTO getCourse(long   courseId);
CourseDTO updateCourse(long   courseId, CourseDTO   courseDTO);

//CourseService loadCourseByCoursename(String courseName);
}
