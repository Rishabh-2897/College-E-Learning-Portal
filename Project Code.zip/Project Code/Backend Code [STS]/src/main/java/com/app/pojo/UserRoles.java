package com.app.pojo;

public enum UserRoles {
	ROLE_USER, ROLE_ADMIN,ROLE_FACULTY,ROLE_STUDENT
}
