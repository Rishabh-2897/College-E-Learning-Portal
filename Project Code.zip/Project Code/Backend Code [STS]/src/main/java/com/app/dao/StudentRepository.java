package com.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.app.pojo.Student;
import com.app.pojo.User;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
	//@Query("select distinct s from Student s join fetch s.roles where s.userName=:nm")
	//Optional<Student> findByStudentName(@Param("nm") String studentName);

}
