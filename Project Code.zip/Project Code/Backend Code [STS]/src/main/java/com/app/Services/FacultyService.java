package com.app.Services;

import java.util.List;
import java.util.Optional;

import com.app.dto.CourseDTO;
import com.app.dto.DepartmentDTO;
import com.app.dto.FacultyDTO;
import com.app.dto.SignUpRequestForFaculty;
import com.app.dto.StudentDTO;
import com.app.dto.SubjectDTO;
import com.app.pojo.AssignClass;
import com.app.pojo.Course;
import com.app.pojo.Faculty;
import com.app.pojo.Subject;

public interface FacultyService {
	
public List<FacultyDTO>getAllFaculty();
FacultyDTO addFaculty(Faculty faculty);
String deleteFaculty(long  facultyId);
FacultyDTO getFaculty(long  facultyId);
FacultyDTO updateFaculty(long  facultyId,FacultyDTO  facultyDTO);
FacultyDTO registerFaculty(SignUpRequestForFaculty request);
//FacultyDTO registerFaculty(Faculty request);

}
