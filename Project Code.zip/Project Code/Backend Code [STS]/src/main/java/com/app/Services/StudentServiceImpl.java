package com.app.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.custom_exc.ResourceNotFoundException;
import com.app.dao.CourseRepository;
import com.app.dao.DepartmentRepository;
import com.app.dao.RoleRepository;
import com.app.dao.StudentRepository;
import com.app.dto.AdminDTO;
import com.app.dto.SignUpRequest;
import com.app.dto.SignUpRequestForStudent;
import com.app.dto.StudentDTO;
import com.app.dto.UserResponseDTO;
import com.app.pojo.Admin;
import com.app.pojo.Course;
import com.app.pojo.Department;
import com.app.pojo.Role;
import com.app.pojo.Student;
import com.app.pojo.StudentDocument;
import com.app.pojo.User;
import com.app.pojo.UserRoles;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {
	@Autowired
	private IUserService userService;
	@Autowired
	private StudentRepository studentRepo;
	@Autowired
	private DepartmentRepository departmentRepo;
	@Autowired
	private CourseRepository courseRepo;
	@Autowired
	private RoleRepository roleRepo;
	@Autowired
	private PasswordEncoder encoder;
	
	public StudentServiceImpl() {}
	
	@Override
	public StudentDTO registerStudent(SignUpRequestForStudent request) {
		// create User from request payload
		/*
		 * { "userName": "Rama", "email": "rama@gmail.com", "password": "ram#12345",
		 * "roles": [ "ROLE_ADMIN" ] }
		 */
		Student student = new Student();
		student.setName(request.getName());
		student.setEmail(request.getEmail());
		student.setAddress(request.getAddress());
		student.setContactno(request.getContactno());
		Department dept=departmentRepo.findById(request.getD_id()).get();
		student.setChosenDepartment(dept);
		Course c=courseRepo.findById(request.getC_id()).get();
		student.setChosenCourse(c);
		student.setPassword(encoder.encode(request.getPassword()));//set encoded pwd
		
//		Set<Role> roles = request.getRoles().stream()//convert Set<String> : role names ---> Stream<String>
//		//mapping roleName --> Role (using RoleRepo) 		
//				.map(roleName -> roleRepo.findByUserRole(UserRoles.valueOf(roleName)).get())
//				//collect in a Set<Role>
//				.collect(Collectors.toSet());
//		student.setRoles(roles);
		student.setActive(true);
		Student persistentStudent = studentRepo.save(student);//persisted user details in db
		SignUpRequest req = new SignUpRequest();
		req.setUserName(student.getName());
		req.setEmail(student.getEmail());
		req.setPassword(request.getPassword());
		req.getRoles().add("ROLE_STUDENT");//ROLE_STUDENT
		userService.registerUser(req);
		StudentDTO dto = new StudentDTO();
		BeanUtils.copyProperties(persistentStudent, dto);//for sending resp : copied User--->User resp DTO
		return dto;
	}
	
			@Override
				public List<StudentDTO> getAllStudents() {
				List<StudentDTO> list = new ArrayList<>();
				studentRepo.findAll().forEach(s -> {
					StudentDTO dto = new StudentDTO();
						BeanUtils.copyProperties(s, dto);
						//dto.setDepartmentName(s.getChosenDepartment().getName());
						//dto.setCourseName(s.getChosenCourse().getName());									
						list.add(dto);
				});
				return list;
				}

	@Override
	public StudentDTO addStudent(Student student) {
	// invoke dao's method for persistence
		Student persistentStudent = studentRepo.save(student);
				// for sending response copy persistent user details ---> user dto(so that you
				// can control what all to share with the front end)
		     StudentDTO dto = new StudentDTO();
				BeanUtils.copyProperties(persistentStudent, dto);
				return dto;
			}// rets a dto  to the caller.
	

	@Override
	public String deleteStudent(long studentId) {
		//below method rets persistent user of exists or throws exc
		Student student = studentRepo.findById(studentId).orElseThrow(() -> new ResourceNotFoundException("Invalid Student ID"));
				studentRepo.deleteById(studentId);
				return "Student details for ID "+studentId+" deleted...";

	}

	@Override
	public StudentDTO getStudent(long studentId) {
		Student student = studentRepo.findById(studentId).orElseThrow(() -> new ResourceNotFoundException("Invalid Student ID"));
		StudentDTO studentDTO = new StudentDTO();
		BeanUtils.copyProperties(student, studentDTO, "password");
		System.out.println("student" + student);
		System.out.println("student DTO  " + studentDTO);
		return studentDTO;
	}

	@Override
	public StudentDTO updateStudent(long studentId, StudentDTO studentDTO) {
		System.out.println("in update " + studentDTO);
		// fetch exsiting details from the db
		Student studentDetails = studentRepo.findById(studentId).get();
		System.out.println("admin dtls from db " + studentDetails);
		// => userDetails : PERSISTENT POJO
		// copy updated user details coming from request payload ---> User details
		BeanUtils.copyProperties(studentDTO,studentDetails);
		studentDetails.setId(studentId);
		studentDTO.setId(studentId);
		System.out.println("updated student dtls " + studentDetails);
		// modified state of persistent POJO
		return studentDTO;
	}
}
