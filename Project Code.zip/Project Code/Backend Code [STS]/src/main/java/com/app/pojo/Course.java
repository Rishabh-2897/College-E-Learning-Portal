package com.app.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Courses")
public class Course {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "course_id")
	private  long courseid;
	@Column(name="course_name",length = 20,unique = true)
	private String name;
	@Column(length = 50)
	private String pattern;
	@Column(length = 10)
	private String duration;
	@Column(length = 10)
	private String fees;
	

	@OneToMany(mappedBy = "chosenCourse",fetch=FetchType.EAGER)
	private List<Student>students;
	
//	@OneToMany(mappedBy = "chosenCourse",cascade = CascadeType.ALL,orphanRemoval = true)
//	private List<Faculty> faculty;
	
	@OneToMany(mappedBy = "chosenCourse",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Attendance> attendance;
	
	@OneToMany(mappedBy = "chosenCourse",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<AssignClass>assignclass;
	
	@OneToMany(mappedBy = "chosenCourse",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Subject>subject;
	
//	@OneToMany(mappedBy = "chosencourse",cascade = CascadeType.ALL,orphanRemoval = true)
//	private List<FileDB>sharedfiles;
	
		
	@ManyToOne
	@JoinColumn(name="d_id",nullable=false)
	private Department chosenDepartment;
		
		public Course(long courseid, String name, String pattern, String duration, String fees, Department chosenDepartment,
			List<Student> students, List<Faculty> faculty, List<Attendance> attendance, List<AssignClass> assignclass,
			List<Subject> subject/* ,List<FileDB> sharedfiles*/) {
		super();
		this.courseid = courseid;
		this.name = name;
		this.pattern = pattern;
		this.duration = duration;
		this.fees = fees;
		this.chosenDepartment = chosenDepartment;
		this.students = students;
		//this.faculty = faculty;
		this.attendance = attendance;
		this.assignclass = assignclass;
		this.subject = subject;
		//this.sharedfiles = sharedfiles;
	}

		public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
		
		public long getId() {
			return courseid;
		}
		
		public void setId(long id) {
			this.courseid = id;
		}
		
		public String getName() {
			return name;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		public String getPattern() {
			return pattern;
		}
		
		public void setPattern(String pattern) {
			this.pattern = pattern;
		}
		
		public String getDuration() {
			return duration;
		}
		
		public void setDuration(String duration) {
			this.duration = duration;
		}
		
		public String getFees() {
			return fees;
		}
		
		public void setFees(String fees) {
			this.fees = fees;
		}
		
		public long getCourseid() {
			return courseid;
		}
		
		public void setCourseid(long courseid) {
			this.courseid = courseid;
		}
		
		public Department getDepartments() {
			return chosenDepartment;
		}
		
		public void setDepartments(Department chosenDepartment) {
			this.chosenDepartment = chosenDepartment;
		}
		
		public List<Student> getStudents() {
			return students;
		}
		
		public void setStudents(List<Student> students) {
			this.students = students;
		}
		
//		public List<Faculty> getFaculty() {
//			return faculty;
//		}
//		
//		public void setFaculty(List<Faculty> faculty) {
//			this.faculty = faculty;
//		}
		
		public List<AssignClass> getAssignclass() {
			return assignclass;
		}
		
		public void setAssignclass(List<AssignClass> assignclass) {
			this.assignclass = assignclass;
			
		}
		
		public List<Subject> getSubject() {
			return subject;
		}
		
		public void setSubject(List<Subject> subject) {
			this.subject = subject;
		}
		
//		public List<FileDB> getSharedfiles() {
//			return sharedfiles;
//		}
//		
//		public void setSharedfiles(List<FileDB> sharedfiles) {
//			this.sharedfiles = sharedfiles;
//		}
//		
		
		public List<Attendance> getAttendance() {
			return attendance;
		}

		public void setAttendance(List<Attendance> attendance) {
			this.attendance = attendance;
		}

		public Department getChosenDepartment() {
		return chosenDepartment;
		}

		public void setChosenDepartment(Department chosenDepartment) {
			this.chosenDepartment = chosenDepartment;
		}

		@Override
		public String toString() {
			return "Course [id=" + courseid + ", name=" + name + ", pattern=" + pattern + ", duration=" + duration + ", fees="
					+ fees + "]";
		}
		
		//helper methods to add n remove student
		public void addStudent(Student s)
		{
			students.add(s);
			s.setChosenCourse(this);
		}
		public void removeStudent(Student s)
		{
			students.remove(s);
			s.setChosenCourse(null);
		}
		
		//helper methods to add n remove faculty
//				public void addFaculty(Faculty f)
//				{
//					faculty.add(f);
//					f.setChosenCourse(this);
//				}
//				public void removeFaculty(Faculty f)
//				{
//					faculty.remove(f);
//					f.setChosenCourse(null);
//				}
				
				//helper methods to add n remove attendance
				public void addAttendance(Attendance a)
				{
					attendance.add(a);
					a.setChosenCourse(this);
				}
				public void removeAttendance(Attendance a)
				{
					attendance.remove(a);
					a.setChosenCourse(null);
				}
				
				//helper methods to add n remove assignclass
				public void addAssignClass(AssignClass as)
				{
					assignclass.add(as);
					as.setChosenCourse(this);
				}
				public void removeAssignClass(AssignClass as)
				{
					assignclass.remove(as);
					as.setChosenCourse(null);
				}
				
				//helper methods to add n remove subject
				public void addSubject(Subject sub)
				{
					subject.add(sub);
					sub.setChosenCourse(this);
				}
				public void removeSubject(Subject sub)
				{
					subject.remove(sub);
					sub.setChosenCourse(null);
				}
				
//				//helper methods to add n remove sharedfiles
//				public void addSharedFiles(FileDB sf)
//				{
//					sharedfiles.add(sf);
//					sf.setChosencourse(this);
//				}
//				public void removeSharedFiled(FileDB sf)
//				{
//					sharedfiles.remove(sf);
//					sf.setChosencourse(null);
//				}
//				
//				//helper methods to add n remove sharedmedia
//				public void addSharedMedia(SharedMedia sm)
//				{
//					sharedmedia.add(sm);
//					sm.setChosencourse(this);
//				}
//				public void removeSharedMedia(SharedMedia sm)
//				{
//					sharedmedia.remove(sm);
//					sm.setChosencourse(null);
//				}


				
}
