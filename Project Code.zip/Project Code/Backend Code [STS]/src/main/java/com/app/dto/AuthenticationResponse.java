package com.app.dto;

public class AuthenticationResponse {
	private final String jwt;
    private String role;
    
    
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	

	public AuthenticationResponse(String jwt, String role) {
		super();
		this.jwt = jwt;
		this.role = role;
	}

	public String getJwt() {
		return jwt;
	}
	
	
}
