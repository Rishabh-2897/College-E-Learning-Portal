package com.app.Services;

import com.app.dto.SignUpRequest;
import com.app.dto.UserResponseDTO;

//Nothing to do with spring security : it's job currently is user registration
public interface IUserService {
	UserResponseDTO registerUser(SignUpRequest request);
}
