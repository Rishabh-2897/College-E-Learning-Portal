package com.app.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "subject")
public class Subject {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
private long subjectid;
private String name;
private int units;


@OneToMany(mappedBy = "chosenSubject",cascade = CascadeType.ALL,orphanRemoval = true)
private List<Attendance> attendance;

@OneToMany(mappedBy = "chosenSubject",cascade = CascadeType.ALL,orphanRemoval = true)
private List<AssignClass>assignclass;

//@OneToMany(mappedBy = "chosenSubject",cascade = CascadeType.ALL,orphanRemoval = true)
//private List<Student>student;

//@OneToMany(mappedBy = "chosenSubject",cascade = CascadeType.ALL,orphanRemoval = true)
//private List<FileDB>sharedfiles;
//
//@OneToMany(mappedBy = "chosenSubject",cascade = CascadeType.ALL,orphanRemoval = true)
//private List<SharedMedia>sharedmedia;

@ManyToOne
@JoinColumn(name="d_id",nullable=false)
private Department chosenDepartment;

@ManyToOne
@JoinColumn(name="c_id",nullable=false)
private Course chosenCourse;

//@ManyToOne
//@JoinColumn(name="f_id",nullable=false)
//private Faculty chosenFaculty;

public Subject() {
	super();
	// TODO Auto-generated constructor stub
}


public Subject(long subjectid, String name, int units, List<Attendance> attendance, List<AssignClass> assignclass,
		/*List<FileDB> sharedfiles,*/ Department chosenDepartment, Course chosenCourse) {
	super();
	this.subjectid = subjectid;
	this.name = name;
	this.units = units;
	this.attendance = attendance;
	this.assignclass = assignclass;
	//this.sharedfiles = sharedfiles;
	this.chosenDepartment = chosenDepartment;
	this.chosenCourse = chosenCourse;
}


/**
 * @return the name
 */
public String getName() {
	return name;
}
/**
 * @param name the name to set
 */
public void setName(String name) {
	this.name = name;
}
/**
 * @return the units
 */
public int getUnits() {
	return units;
}
/**
 * @param units the units to set
 */
public void setUnits(int units) {
	this.units = units;
}

/**
 * @return the id
 */
public long getId() {
	return subjectid;
}

/**
 * @param id the id to set
 */
public void setId(long id) {
	this.subjectid = id;
}

/**
 * @return the assignclass
 */
public List<AssignClass> getAssignclass() {
	return assignclass;
}

/**
 * @param assignclass the assignclass to set
 */
public void setAssignclass(List<AssignClass> assignclass) {
	this.assignclass = assignclass;
}

/**
 * @return the chosenDepartment
 */
public Department getChosenDepartment() {
	return chosenDepartment;
}

/**
 * @param chosenDepartment the chosenDepartment to set
 */
public void setChosenDepartment(Department chosenDepartment) {
	this.chosenDepartment = chosenDepartment;
}


///**
// * @return the sharedfiles
// */
//public List<FileDB> getSharedfiles() {
//	return sharedfiles;
//}
//
///**
// * @param sharedfiles the sharedfiles to set
// */
//public void setSharedfiles(List<FileDB> sharedfiles) {
//	this.sharedfiles = sharedfiles;
//}

/**
 * @return the chosenCourse
 */
public Course getChosenCourse() {
	return chosenCourse;
}

/**
 * @param chosenCourse the chosenCourse to set
 */
public void setChosenCourse(Course chosenCourse) {
	this.chosenCourse = chosenCourse;
}

@Override
public String toString() {
	return "Subject [ name=" + name + ", units=" + units + "]";
}

//helper methods to add n remove attendance
public void addAttendance(Attendance a)
{
	attendance.add(a);
	a.setChosenSubject(this);
}
public void removeAttendance(Attendance a)
{
	attendance.remove(a);
	a.setChosenSubject(this);
}

//helper methods to add n remove assignclass
public void addAssignClass(AssignClass as)
{
	assignclass.add(as);
	as.setChosenSubject(this);
}
public void removeAssignClass(AssignClass as)
{
	assignclass.remove(as);
	as.setChosenSubject(null);
}

////helper methods to add n remove sharedfiles
//public void addSharedFiles(FileDB sf)
//{
//	sharedfiles.add(sf);
//	sf.setChosenSubject(this);
//}
//public void removeSharedFiled(FileDB sf)
//{
//	sharedfiles.remove(sf);
//	sf.setChosenSubject(null);
//}
//
////helper methods to add n remove sharedmedia
//public void addSharedMedia(SharedMedia sm)
//{
//	sharedmedia.add(sm);
//	sm.setChosenSubject(this);
//}
//public void removeSharedMedia(SharedMedia sm)
//{
//	sharedmedia.remove(sm);
//	sm.setChosenSubject(null);
//}

}

