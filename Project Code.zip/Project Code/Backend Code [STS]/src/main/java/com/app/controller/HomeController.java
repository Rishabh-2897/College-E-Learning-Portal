package com.app.controller;

import java.security.Principal;
import java.util.Enumeration;

import javax.servlet.http.HttpSession;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class HomeController {
	@GetMapping("/")	
	public String testNoAuth(Principal principal) {
		System.out.println("in no auth "+principal);
		return "welcome all !!!!!   ";
	}
	@GetMapping("/user")	
	public String testUserAuth(Principal principal) {
		System.out.println("in user auth "+principal);
		return "welcome user !!!!! "+principal.getName();
	}
	@GetMapping("/admin")	
	public String testAdminAuth(Principal principal) {
		System.out.println("in admin auth "+principal);
		return "welcome admin !!!!! "+principal.getName();
	}
	@GetMapping("/faculty")	
	public String testFacultyAuth(Principal principal) {
		System.out.println("in faculty auth "+principal);
		return "welcome faculty !!!!! "+principal.getName();
	}
	@GetMapping("/student")	
	public String testStudentAuth(Principal principal) {
		System.out.println("in student auth "+principal);
		return "welcome student !!!!! "+principal.getName();
	}
	
}
