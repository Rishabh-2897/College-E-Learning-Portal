package com.app.pojo;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.app.pojo.Student;



@Entity
@Table(name = "student_docs")
public class StudentDocument {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "doc_id")
	private long Documentid;
	@Enumerated(EnumType.STRING)
	@Column(length = 50)
	private DocumentDescription description;
	@Column(name = "doc_path")
	private String documentpath;
		
	@ManyToOne
		@JoinColumn(name="s_id",nullable = false)
		private Student studentDetails;
	
		public StudentDocument() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentDocument(long documentid, String documentDescription, String documentpath, Student studentDetails) {
		super();
		Documentid = documentid;
		//this.documentDescription = documentDescription;
		this.documentpath = documentpath;
		this.studentDetails = studentDetails;
		
	}

	/**
	 * @return the documentid
	 */
	public long getDocumentid() {
		return Documentid;
	}

	/**
	 * @param documentid the documentid to set
	 */
	public void setDocumentid(long documentid) {
		Documentid = documentid;
	}

	/**
	 * @return the documentpath
	 */
	public String getDocumentpath() {
		return documentpath;
	}

	/**
	 * @param documentpath the documentpath to set
	 */
	public void setDocumentpath(String documentpath) {
		this.documentpath = documentpath;
	}

	/**
	 * @return the studentDetails
	 */
	public Student getStudentDetails() {
		return studentDetails;
	}

	/**
	 * @param studentDetails the studentDetails to set
	 */
	public void setStudentDetails(Student studentDetails) {
		this.studentDetails = studentDetails;
	}

	
	@Override
	public String toString() {
		return "StudentDocument [Documentid=" + Documentid + ", description=" + description + ", documentpath=" + documentpath + ", studentDetails=" + studentDetails + "]";
	}

	

	
		
	}
	
	
	
	
	
			
			
			


