package com.app.dto;

import java.util.HashSet;
import java.util.Set;

public class SignUpRequestForFaculty {
	
	//Input data
//	"d_id": "5",
//    "faculty_name": "Ram",
//    "contact_no": "789456",
//    "email": "ram@gmail.com",
//    "specialization": "JAVA,AWP",
//    "username": "ram@gmail.com",
//    "password": "123"
	private long d_id;
	//private long c_id;
	private String faculty_name;
	private String email;
	private String contact_no;
	private String specialization;
	private String username;
	private String password;
	private Set<String> roles=new HashSet<>();
	public long getD_id() {
		return d_id;
	}
	public void setD_id(long d_id) {
		this.d_id = d_id;
	}
//	public long getC_id() {
//		return c_id;
//	}
//	public void setC_id(long c_id) {
//		this.c_id = c_id;
//	}
	public String getFaculty_name() {
		return faculty_name;
	}
	public void setFaculty_name(String faculty_name) {
		this.faculty_name = faculty_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact_no() {
		return contact_no;
	}
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Set<String> getRoles() {
		return roles;
	}
	public void setRoles(Set<String> roles) {
		this.roles = roles;
	}
	@Override
	public String toString() {
		return "SignUpRequestForFaculty [d_id=" + d_id + ", faculty_name=" + faculty_name + ", email=" + email
				+ ", contact_no=" + contact_no + ", specialization=" + specialization + ", username=" + username
				+ ", password=" + password + ", roles=" + roles + "]";
	}
	
	
	
	
}
