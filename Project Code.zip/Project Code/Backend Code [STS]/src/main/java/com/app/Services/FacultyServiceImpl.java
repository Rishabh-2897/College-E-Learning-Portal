package com.app.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.custom_exc.ResourceNotFoundException;
import com.app.dao.CourseRepository;
import com.app.dao.DepartmentRepository;
import com.app.dao.FacultyRepository;
import com.app.dao.RoleRepository;
import com.app.dto.FacultyDTO;
import com.app.dto.SignUpRequest;
import com.app.dto.SignUpRequestForFaculty;
import com.app.dto.SignUpRequestForStudent;
import com.app.dto.StudentDTO;
import com.app.pojo.AssignClass;
import com.app.pojo.Course;
import com.app.pojo.Department;
import com.app.pojo.Faculty;
import com.app.pojo.Role;
import com.app.pojo.Student;
import com.app.pojo.Subject;
import com.app.pojo.UserRoles;

@Service
@Transactional
public class FacultyServiceImpl implements FacultyService{
	@Autowired
	private IUserService userService;
	@Autowired
	private FacultyRepository facultyRepo;
	@Autowired
	private DepartmentRepository departmentRepo;
	@Autowired
	private CourseRepository courseRepo;
	@Autowired
	private RoleRepository roleRepo;
	@Autowired
	private PasswordEncoder encoder;
	
	public FacultyServiceImpl() {}
	
	@Override
	public FacultyDTO registerFaculty(SignUpRequestForFaculty request) {
		// create User from request payload
		/*
		 * { "userName": "Rama", "email": "rama@gmail.com", "password": "ram#12345",
		 * "roles": [ "ROLE_ADMIN" ] }
		 */
		Faculty faculty = new Faculty();
		faculty.setName(request.getUsername());
		faculty.setEmail(request.getEmail());
		faculty.setContactno(request.getContact_no());
		faculty.setSpecialization(request.getSpecialization());
		Department dept=departmentRepo.findById(request.getD_id()).get();
		faculty.setChosenDepartment(dept);
		//Course c=courseRepo.findById(request.getC_id()).get();
		//faculty.setChosenCourse(c);
		faculty.setPassword(encoder.encode(request.getPassword()));//set encoded pwd
		
//		Set<Role> roles = request.getRoles().stream()//convert Set<String> : role names ---> Stream<String>
//		//mapping roleName --> Role (using RoleRepo) 		
//				.map(roleName -> roleRepo.findByUserRole(UserRoles.valueOf(roleName)).get())
//				//collect in a Set<Role>
//				.collect(Collectors.toSet());
//		faculty.setRoles(roles);
		
		faculty.setActive(true);
		Faculty persistentfaculty = facultyRepo.save(faculty);//persisted user details in faculty table
		//to do : Add username encoded password, role into users table
				//refer to user signin signup controller register user 
				//create user instance with username and encoded password and hardcode role
		SignUpRequest req = new SignUpRequest();
		req.setUserName(faculty.getName());
		req.setEmail(faculty.getEmail());
		req.setPassword(request.getPassword());
		req.getRoles().add("ROLE_FACULTY");//ROLE_STUDENT
		userService.registerUser(req);
		FacultyDTO dto = new FacultyDTO();
		BeanUtils.copyProperties(persistentfaculty, dto);//for sending resp : copied User--->User resp DTO
		return dto;
	}
	
	@Override
	public List<FacultyDTO> getAllFaculty() {
		List<FacultyDTO> list = new ArrayList<>();
		facultyRepo.findAll().forEach(f -> {
			FacultyDTO dto = new FacultyDTO();
			BeanUtils.copyProperties(f, dto);
			list.add(dto);
		});
		return list;
	}

	@Override
	public FacultyDTO addFaculty(Faculty faculty) {
		// invoke dao's method for persistence
		Faculty persistentFaculty = facultyRepo.save(faculty);
		// for sending response copy persistent user details ---> user dto(so that you
		// can control what all to share with the front end)
		FacultyDTO dto = new FacultyDTO();
		BeanUtils.copyProperties(persistentFaculty, dto);
		dto.setDepartmentName(persistentFaculty.getChosenDepartment().getName());
		//dto.setCourseName(persistentFaculty.getChosenCourse().getName());
		return dto;
	}// rets a dto  to the caller.

	

	@Override
	public String deleteFaculty(long facultyId) {
		//below method rets persistent user of exists or throws exc
		Faculty faculty = facultyRepo.findById(facultyId).orElseThrow(() -> new ResourceNotFoundException("Invalid faculty ID"));
		facultyRepo.deleteById(facultyId);
		return "Faculty details for ID "+facultyId+" deleted...";

	}

	@Override
	public FacultyDTO getFaculty(long facultyId) {
		Faculty faculty = facultyRepo.findById(facultyId).orElseThrow(() -> new ResourceNotFoundException("Invalid faculty ID"));
		FacultyDTO facultyDTO = new FacultyDTO();
		BeanUtils.copyProperties(faculty, facultyDTO);
		System.out.println("faculty" + faculty);
		System.out.println("faculty DTO  " + facultyDTO);
		return facultyDTO;
	}

	@Override
	public FacultyDTO updateFaculty(long facultyId, FacultyDTO facultyDTO) {
		System.out.println("in update " + facultyDTO);
		// fetch exsiting details from the db
		Faculty facultydetails= facultyRepo.findById(facultyId).get();
		System.out.println("faculty from db " + facultydetails);
		// => userDetails : PERSISTENT POJO
		// copy updated user details coming from request payload ---> User details
		BeanUtils.copyProperties(facultyDTO, facultydetails);
		facultydetails.setId(facultyId);
		facultyDTO.setId(facultyId);
		System.out.println("updated faculty dtls " + facultydetails);
		// modified state of persistent POJO
		return facultyDTO;
	}

	

}
