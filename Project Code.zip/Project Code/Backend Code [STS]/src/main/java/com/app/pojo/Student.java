package com.app.pojo;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "student")
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "student_id")
	private long id;
	@Column(name = "student_name",length = 50,nullable = false)
	private String name;
	@Column(length = 50)
	private String address;
	@Column(length = 10)
	private String contactno;
	@Column(length = 50)
	private String email;
	@Column(length = 50)
	private String userName;
	@Column(nullable = false)
	private String password;
	
	private boolean active;
	//uni dir many-to-many from User *<----->*
	@ManyToMany
	@JoinTable(name = "user_roles", 
	joinColumns = @JoinColumn(name = "user_id"), 
	inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<Role> roles = new HashSet<>();

	
	@OneToMany(mappedBy = "studentDetails",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<StudentDocument> studoc;
	
	@OneToMany(mappedBy = "students",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Attendance> attendance;
	
	@ManyToOne
	@JoinColumn(name="d_id",nullable=false)
	private Department chosenDepartment;
	
	@ManyToOne
	@JoinColumn(name="c_id",nullable=false)
	private Course chosenCourse;
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Student(long id, String name, String address, String contactno, String email, String userName,
			String password, boolean active, Set<Role> roles, List<StudentDocument> studoc, List<Attendance> attendance,
			Department chosenDepartment, Course chosenCourse) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.contactno = contactno;
		this.email = email;
		this.userName = userName;
		this.password = password;
		this.active = active;
		this.roles = roles;
		this.studoc = studoc;
		this.attendance = attendance;
		this.chosenDepartment = chosenDepartment;
		this.chosenCourse = chosenCourse;
	}


	
	
	
	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getContactno() {
		return contactno;
	}


	public void setContactno(String contactno) {
		this.contactno = contactno;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public boolean isActive() {
		return active;
	}


	public void setActive(boolean active) {
		this.active = active;
	}


	public Set<Role> getRoles() {
		return roles;
	}


	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}


	public List<StudentDocument> getStudoc() {
		return studoc;
	}


	public void setStudoc(List<StudentDocument> studoc) {
		this.studoc = studoc;
	}


	public List<Attendance> getAttendance() {
		return attendance;
	}


	public void setAttendance(List<Attendance> attendance) {
		this.attendance = attendance;
	}


	public Department getChosenDepartment() {
		return chosenDepartment;
	}


	public void setChosenDepartment(Department string) {
		this.chosenDepartment = string;
	}


	public Course getChosenCourse() {
		return chosenCourse;
	}


	public void setChosenCourse(Course chosenCourse) {
		this.chosenCourse = chosenCourse;
	}


	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", address=" + address + ", contactno=" + contactno + ", email="
				+ email + ", userName=" + userName + ", password=" + password + ", active=" + active + ", roles="
				+ roles + ", studoc=" + studoc + ", attendance=" + attendance + ", chosenDepartment=" + chosenDepartment
				+ ", chosenCourse=" + chosenCourse + "]";
	}

	//helper methods to add n remove attendance
	public void addAttendance(Attendance a)
	{
		attendance.add(a);
		a.setStudents(this);
	}
	public void removeAttendance(Attendance a)
	{
		attendance.remove(a);
		a.setStudents(null);
	}
		//helper methods to add n remove studentdocuments
		public void addStudentDocument(StudentDocument std)
		{
			studoc.add(std);
			std.setStudentDetails(this);
		}
		public void removeStudentDocument(StudentDocument std)
		{
			studoc.remove(std);
			std.setStudentDetails(null);
		}


}
